# NetGuardian: Intelligent Autonomous Network Anomaly Detection & Device-Specific Resolution System

**NetGuardian** is a full-stack, enterprise-grade network monitoring, ML-driven anomaly detection, root cause analysis (RCA), outage impact prediction, and targeted automated problem-resolution web application.

---

## 🚀 Key Highlights & Architectural Principles

1. **True Autonomous Operation**:
   The network administrator simply connects a device and saves its default thresholds. The system automatically begins real-time telemetry probing, statistical & Isolation Forest anomaly classification, RCA, topology blast-radius forecasting, and device-targeted automated resolution.
2. **Device Isolation & Side-Effect Protection**:
   Remediation actions target the failing device specifically. Before applying any fix, NetGuardian captures a snapshot of all peer devices. After the repair, it verifies recovery on the target device and guarantees zero adverse side-effects on connected peer nodes.
3. **Recovery Verification**:
   No incident is marked as resolved until fresh metrics confirm that packet loss, latency, and reachability have returned safely within threshold baselines.
4. **Graph Topology Blast Radius**:
   Computes transitive downstream dependencies to forecast which business services and network nodes will be impacted before an outage cascades.

---

## 🛠 Technology Stack

- **Frontend**: Single Page Application (SPA) with custom dark mode glassmorphism UI, SVG-based real-time telemetry sparklines/charts, and interactive network topology visualization.
- **Backend**: Python 3.13, FastAPI REST APIs, SQLite with time-series metrics indexing.
- **AI/ML Engine**: Scikit-Learn (`IsolationForest`), NumPy, Pandas for multivariate behavioral deviation and adaptive statistical thresholding.
- **Security & Roles**: Secure SHA-256 / JWT authentication, Protected endpoints, Admin and Network Administrator roles.

---

## 📂 Project Structure

```
NetGuardian/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py              # FastAPI REST endpoints & static server
│   │   ├── database.py          # SQLite schema, tables, indexes, and defaults
│   │   ├── auth.py              # JWT authentication & password security
│   │   ├── monitor.py           # Background continuous telemetry probing engine
│   │   ├── prober.py            # ICMP ping, HTTP, and DNS socket probers
│   │   ├── anomaly_engine.py    # Isolation Forest & multi-metric anomaly detection
│   │   ├── rca_engine.py        # Root Cause Analysis cross-correlation engine
│   │   ├── impact_engine.py     # Graph-based outage impact prediction
│   │   ├── auto_resolution.py   # Targeted remediation, rollback & peer protection
│   │   └── seed_data.py         # Default enterprise network topology & initial devices
│   └── netguardian.db
├── frontend/
│   ├── index.html               # Main HTML entrypoint
│   └── static/
│       ├── css/
│       │   └── styles.css       # Complete modern CSS system & dark mode theme
│       └── js/
│           └── app.js           # SPA router, SVG charts, live polling & scenario controllers
├── requirements.txt
└── README.md
```

---

## ⚡ How to Run the Application

### 1. Install Backend Dependencies
Ensure Python 3.10+ is installed:
```bash
pip install fastapi uvicorn scikit-learn pandas numpy pyjwt passlib
```

### 2. Launch the NetGuardian Server
Run the FastAPI application with Uvicorn:
```bash
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### 3. Access the Dashboard
Open your web browser and navigate to:
```
http://localhost:8000
```
- **Default Admin Username**: `admin`
- **Default Password**: `admin123`

---

## 🧪 Testing the 7 Demonstration Scenarios

NetGuardian includes built-in scenario injection buttons at the top of the dashboard:

1. **Scenario 1 (Normal Baseline)**: Clears all fault injections; verifies all nodes green and metrics optimal.
2. **Scenario 2 (High Latency)**: Spikes latency on Device A (`App-Server-SRV1`); triggers Isolation Forest anomaly, alert, and targeted QoS traffic shaping fix.
3. **Scenario 3 (Connection Loss)**: Simulates complete disconnection on Device A; evaluates consecutive failed checks, generates critical alert, and diagnoses link vs device failure.
4. **Scenario 4 (Packet Loss)**: Injects 25–40% packet drops; RCA correlates interface errors and recommends interface buffer clearing.
5. **Scenario 5 (Router Outage)**: Simulates Core Router R1 outage; graph topology computes transitive downstream partition across switches and dependent enterprise services.
6. **Scenario 6 & 7 (Recovery Verification & Peer Protection)**: Executes targeted repair on Device A only, verifies that Device B and Device C maintain 100% reachability, and transitions incident to **Resolved**.
