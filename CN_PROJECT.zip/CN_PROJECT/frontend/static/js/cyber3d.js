/**
 * NetGuardian Isometric 3D Cyber Sentinel Topology Engine
 * Matching Cyber Sentinel Enterprise Security Dashboard:
 * - Hexagonal isometric holographic pedestals with glowing concentric rings
 * - Isometric 3D device icons (Server, Firewall, Database, Router, PC, Laptop, Mobile, IoT Gateway)
 * - Directed glowing data flows with bi-directional arrowheads and pulsing energetic packets
 * - Interactive Device-to-Device connection linking mode (Click Device A -> Click Device B -> Instantly Link)
 * - Real-time Fault visualization: Red flashing beacon, fragmented broken lines, and warning halos
 * - Color scheme matching reference:
 *     * Teal / Cyan (#06b6d4, #00f0ff) for Database & Core Servers
 *     * Magenta / Violet (#d946ef, #c026d3) for Firewalls & Routers
 *     * Purple / Lilac (#a855f7) for User Workstations & IoT Gateways
 *     * Red Alert (#ef4444) for Faults & Disconnections
 */

class NetGuardianCyber3DViewer {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.options = options;
    this.devices = [];
    this.links = [];
    this.metrics = [];
    this.selectedDevice = null;
    this.connectSourceDevice = null; // Used for "Connect Device A to B" feature
    this.isConnectMode = false;
    this.searchQuery = "";
    this.statusFilter = "ALL";

    // View Transformation (Pan & Zoom)
    this.scale = 1.0;
    this.pan = { x: 0, y: 0 };
    this.isDragging = false;
    this.lastMouse = { x: 0, y: 0 };
    this.animTime = 0;

    // Node Positions Layout Map
    this.nodePositions = {};

    this.initCanvas();
    this.bindEvents();
    this.animate = this.animate.bind(this);
    this.animationFrameId = requestAnimationFrame(this.animate);
  }

  initCanvas() {
    this.container.innerHTML = "";
    this.container.style.position = "relative";
    this.container.style.overflow = "hidden";
    this.container.style.userSelect = "none";
    this.container.style.background = "radial-gradient(ellipse at center, #0f172a 0%, #070b14 100%)";

    this.canvas = document.createElement("canvas");
    this.canvas.style.width = "100%";
    this.canvas.style.height = "100%";
    this.canvas.style.display = "block";
    this.container.appendChild(this.canvas);

    this.ctx = this.canvas.getContext("2d");
    this.resize();
  }

  resize() {
    if (!this.container || !this.canvas) return;
    const rect = this.container.getBoundingClientRect();
    this.width = rect.width || 800;
    this.height = rect.height || 600;
    this.canvas.width = this.width * window.devicePixelRatio;
    this.canvas.height = this.height * window.devicePixelRatio;
    this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }

  updateData(devices, links, metrics = []) {
    this.devices = devices || [];
    this.links = links || [];
    this.metrics = metrics || [];
    this.computeNodeLayout();
  }

  computeNodeLayout() {
    const count = this.devices.length;
    if (count === 0) return;

    const cx = this.width / 2;
    const cy = this.height / 2;

    // Arrange in aesthetic Cyber-Sentinel multi-cluster layout
    // Center: Firewall / Core Distribution
    // Left: Database Clusters & Web Servers (Cyan)
    // Right: User Stations & Workstations (Purple)
    // Bottom: IoT Gateways & Printers

    this.devices.forEach((dev, idx) => {
      if (this.nodePositions[dev.id]) return; // keep consistent positions

      const dType = dev.device_type || "";
      let x = cx;
      let y = cy;

      if (dType === "Router" || dType === "Switch") {
        // Central tier
        x = cx + (idx % 2 === 0 ? -60 : 70);
        y = cy + (idx % 2 === 0 ? 30 : -40);
      } else if (dType === "Server") {
        // Left tier (Database / Web servers)
        x = cx - 240 + ((idx * 60) % 140);
        y = cy - 120 + ((idx * 110) % 220);
      } else if (dType.includes("Desktop") || dType.includes("Laptop")) {
        // Right / Bottom Right (User Workstations)
        x = cx + 220 + ((idx * 50) % 120);
        y = cy - 110 + ((idx * 120) % 240);
      } else if (dType.includes("Access Point") || dType.includes("Printer")) {
        // Bottom cluster (IoT Gateways)
        x = cx + (idx % 2 === 0 ? -120 : 160);
        y = cy + 180;
      } else {
        const angle = (idx / count) * Math.PI * 2;
        x = cx + Math.cos(angle) * 220;
        y = cy + Math.sin(angle) * 160;
      }

      this.nodePositions[dev.id] = { x, y };
    });
  }

  bindEvents() {
    window.addEventListener("resize", () => this.resize());

    this.canvas.addEventListener("mousedown", (e) => {
      this.isDragging = true;
      this.lastMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener("mousemove", (e) => {
      if (!this.isDragging) return;
      const dx = e.clientX - this.lastMouse.x;
      const dy = e.clientY - this.lastMouse.y;
      this.pan.x += dx;
      this.pan.y += dy;
      this.lastMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener("mouseup", () => {
      this.isDragging = false;
    });

    this.canvas.addEventListener("wheel", (e) => {
      e.preventDefault();
      const zoom = e.deltaY < 0 ? 1.08 : 0.92;
      this.scale = Math.max(0.4, Math.min(2.5, this.scale * zoom));
    }, { passive: false });

    // Click handler for node selection and interactive linking
    this.canvas.addEventListener("click", (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const mouseX = (e.clientX - rect.left - this.pan.x) / this.scale;
      const mouseY = (e.clientY - rect.top - this.pan.y) / this.scale;

      let hitDevice = null;
      this.devices.forEach(dev => {
        const pos = this.nodePositions[dev.id];
        if (!pos) return;
        const dist = Math.hypot(pos.x - mouseX, pos.y - mouseY);
        if (dist <= 38) {
          hitDevice = dev;
        }
      });

      if (this.isConnectMode && hitDevice) {
        // Linking Mode: Select A -> Select B -> Connect
        if (!this.connectSourceDevice) {
          this.connectSourceDevice = hitDevice;
          if (this.options.onConnectPrompt) {
            this.options.onConnectPrompt(`Selected ${hitDevice.name}. Now click target device to link.`);
          }
        } else if (this.connectSourceDevice.id !== hitDevice.id) {
          const src = this.connectSourceDevice;
          const tgt = hitDevice;
          this.connectSourceDevice = null;
          this.isConnectMode = false;
          if (this.options.onEstablishLink) {
            this.options.onEstablishLink(src.id, tgt.id);
          }
        }
      } else {
        this.selectedDevice = hitDevice;
        if (this.options.onSelect) {
          this.options.onSelect(hitDevice);
        }
      }
    });
  }

  setConnectMode(enabled) {
    this.isConnectMode = enabled;
    this.connectSourceDevice = null;
  }

  resetView() {
    this.scale = 1.0;
    this.pan = { x: 0, y: 0 };
  }

  animate(time) {
    this.animTime = time * 0.001;
    this.render();
    this.animationFrameId = requestAnimationFrame(this.animate);
  }

  render() {
    const ctx = this.ctx;
    if (!ctx) return;

    ctx.save();
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Apply Pan & Zoom
    ctx.translate(this.pan.x, this.pan.y);
    ctx.scale(this.scale, this.scale);

    // 1. Draw Cyber Isometric Grid Floor
    this.renderCyberGrid(ctx);

    // 2. Draw Network Edges (Connections) with pulses & arrows
    this.renderConnections(ctx);

    // 3. Draw Connecting Pending Line if in Connect Mode
    if (this.isConnectMode && this.connectSourceDevice) {
      const pos = this.nodePositions[this.connectSourceDevice.id];
      if (pos) {
        ctx.save();
        ctx.setLineDash([6, 6]);
        ctx.strokeStyle = "#00f0ff";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 48 + Math.sin(this.animTime * 8) * 4, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4. Draw Isometric 3D Device Nodes & Hologram Pedestals
    this.devices.forEach(dev => {
      // Filter check
      if (this.statusFilter === "ONLINE" && dev.reachability_status !== "Reachable") return;
      if (this.statusFilter === "OFFLINE" && dev.reachability_status === "Reachable") return;
      if (this.statusFilter === "WARNING" && dev.status !== "Degraded") return;
      if (this.searchQuery && !dev.name.toLowerCase().includes(this.searchQuery.toLowerCase()) && !dev.ip_address.includes(this.searchQuery)) return;

      this.renderDeviceNode(ctx, dev);
    });

    ctx.restore();
  }

  renderCyberGrid(ctx) {
    ctx.save();
    ctx.strokeStyle = "rgba(30, 41, 59, 0.35)";
    ctx.lineWidth = 1;

    const w = this.width * 2;
    const h = this.height * 2;
    const step = 48;

    ctx.beginPath();
    for (let x = -w / 2; x <= w; x += step) {
      ctx.moveTo(x, -h / 2);
      ctx.lineTo(x, h);
    }
    for (let y = -h / 2; y <= h; y += step) {
      ctx.moveTo(-w / 2, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();

    // Subtle background cyan/purple ambient glows
    const radial = ctx.createRadialGradient(this.width / 2, this.height / 2, 40, this.width / 2, this.height / 2, 450);
    radial.addColorStop(0, "rgba(6, 182, 212, 0.08)");
    radial.addColorStop(0.6, "rgba(168, 85, 247, 0.04)");
    radial.addColorStop(1, "transparent");
    ctx.fillStyle = radial;
    ctx.fillRect(-w / 2, -h / 2, w * 2, h * 2);

    ctx.restore();
  }

  renderConnections(ctx) {
    const t = this.animTime;

    this.links.forEach(link => {
      const p1 = this.nodePositions[link.source_device_id];
      const p2 = this.nodePositions[link.target_device_id];
      if (!p1 || !p2) return;

      const srcDev = this.devices.find(d => d.id === link.source_device_id);
      const tgtDev = this.devices.find(d => d.id === link.target_device_id);

      // Fault evaluation
      const isFault = (srcDev && srcDev.reachability_status !== "Reachable") || 
                      (tgtDev && tgtDev.reachability_status !== "Reachable") || 
                      link.status !== "Up";
      const isWarning = (srcDev && srcDev.status === "Degraded") || 
                        (tgtDev && tgtDev.status === "Degraded");

      let strokeColor = "#00f0ff"; // Vibrant Cyber Teal
      let glowColor = "rgba(0, 240, 255, 0.6)";

      if (isFault) {
        strokeColor = "#ef4444"; // Red fault
        glowColor = "rgba(239, 68, 68, 0.8)";
      } else if (isWarning) {
        strokeColor = "#f59e0b"; // Warning amber
        glowColor = "rgba(245, 158, 11, 0.6)";
      }

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);

      if (isFault) {
        // Red Fragmented/Broken line for link loss
        ctx.setLineDash([8, 8]);
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 2.8;
        ctx.shadowColor = glowColor;
        ctx.shadowBlur = 12;
        ctx.stroke();

        // Pulsing Red Warning Beacon at midpoint
        const mx = (p1.x + p2.x) / 2;
        const my = (p1.y + p2.y) / 2;
        ctx.beginPath();
        ctx.arc(mx, my, 6 + Math.sin(t * 8) * 2, 0, Math.PI * 2);
        ctx.fillStyle = "#ef4444";
        ctx.shadowColor = "#ef4444";
        ctx.shadowBlur = 14;
        ctx.fill();
      } else {
        // Solid Glowing Connection with Directed Arrowheads & Traveling Energy Pulses
        ctx.setLineDash([]);
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 2.2;
        ctx.shadowColor = glowColor;
        ctx.shadowBlur = 10;
        ctx.stroke();

        // Bi-directional cyber arrowheads
        this.renderArrowhead(ctx, p1, p2, 0.55, strokeColor);
        this.renderArrowhead(ctx, p2, p1, 0.45, strokeColor);

        // Travelling Energy Packets (Animated dots)
        const progress1 = (t * 0.4) % 1.0;
        const progress2 = (t * 0.4 + 0.5) % 1.0;

        [progress1, progress2].forEach(p => {
          const px = p1.x + (p2.x - p1.x) * p;
          const py = p1.y + (p2.y - p1.y) * p;

          ctx.beginPath();
          ctx.arc(px, py, 3.5, 0, Math.PI * 2);
          ctx.fillStyle = "#ffffff";
          ctx.shadowColor = strokeColor;
          ctx.shadowBlur = 14;
          ctx.fill();
        });
      }
      ctx.restore();
    });
  }

  renderArrowhead(ctx, from, to, posFraction, color) {
    const x = from.x + (to.x - from.x) * posFraction;
    const y = from.y + (to.y - from.y) * posFraction;
    const angle = Math.atan2(to.y - from.y, to.x - from.x);
    const arrowLen = 8;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-arrowLen, -arrowLen / 2);
    ctx.lineTo(-arrowLen, arrowLen / 2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  renderDeviceNode(ctx, dev) {
    const pos = this.nodePositions[dev.id];
    if (!pos) return;

    const isOffline = dev.reachability_status !== "Reachable" || dev.status === "Connection Failed";
    const isWarning = dev.status === "Degraded";
    const isSelected = this.selectedDevice && this.selectedDevice.id === dev.id;
    const isConnectSource = this.connectSourceDevice && this.connectSourceDevice.id === dev.id;

    const dType = dev.device_type || "";
    const t = this.animTime;

    // Palette assignment
    let mainColor = "#00f0ff"; // Cyan for servers / default
    let glowColor = "rgba(0, 240, 255, 0.4)";
    let badgeType = "SERVER";

    if (dType === "Router" || dType === "Switch") {
      mainColor = "#d946ef"; // Magenta / Violet
      glowColor = "rgba(217, 70, 239, 0.4)";
      badgeType = "FIREWALL / ROUTER";
    } else if (dType.includes("Desktop") || dType.includes("Laptop")) {
      mainColor = "#a855f7"; // Purple
      glowColor = "rgba(168, 85, 247, 0.4)";
      badgeType = "USER ENDPOINT";
    } else if (dType.includes("Access Point") || dType.includes("Printer")) {
      mainColor = "#8b5cf6"; // Lilac
      glowColor = "rgba(139, 92, 246, 0.4)";
      badgeType = "IOT GATEWAY";
    }

    if (isOffline) {
      mainColor = "#ef4444"; // Critical Red
      glowColor = "rgba(239, 68, 68, 0.7)";
    } else if (isWarning) {
      mainColor = "#f59e0b"; // Warning Amber
      glowColor = "rgba(245, 158, 11, 0.6)";
    }

    ctx.save();

    // 1. Isometric Hexagonal Holographic Base / Pedestal
    ctx.save();
    ctx.translate(pos.x, pos.y + 12);
    ctx.scale(1.2, 0.55); // Isometric elliptical compression

    // Animated breathing ring
    ctx.beginPath();
    ctx.arc(0, 0, 32 + (isSelected ? Math.sin(t * 8) * 3 : 0), 0, Math.PI * 2);
    ctx.strokeStyle = isSelected ? "#38bdf8" : mainColor;
    ctx.lineWidth = isSelected ? 3 : 1.8;
    ctx.shadowColor = mainColor;
    ctx.shadowBlur = isOffline ? 16 : 10;
    ctx.stroke();

    // Fill semi-transparent base
    ctx.fillStyle = isOffline ? "rgba(239, 68, 68, 0.15)" : "rgba(15, 23, 42, 0.7)";
    ctx.fill();
    ctx.restore();

    // 2. Central 3D Device Orb / Block
    ctx.beginPath();
    ctx.arc(pos.x, pos.y - 4, 22, 0, Math.PI * 2);
    ctx.fillStyle = "#0c1322";
    ctx.strokeStyle = mainColor;
    ctx.lineWidth = 2.4;
    ctx.shadowColor = mainColor;
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.stroke();

    // 3. Isometric Icon representation
    ctx.fillStyle = isOffline ? "#f87171" : "#ffffff";
    ctx.font = "bold 13px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    let iconText = "▤";
    if (dType === "Router") iconText = "⌁";
    else if (dType === "Switch") iconText = "⇄";
    else if (dType.includes("Desktop")) iconText = "💻";
    else if (dType.includes("Laptop")) iconText = "⌨";
    else if (dType.includes("Access Point")) iconText = "📶";
    else if (dType.includes("Printer")) iconText = "🖨";
    else if (dType.includes("Mobile")) iconText = "📱";
    ctx.fillText(iconText, pos.x, pos.y - 4);

    // 4. Glowing Status Indicator Dot
    ctx.beginPath();
    ctx.arc(pos.x + 16, pos.y - 18, 5, 0, Math.PI * 2);
    ctx.fillStyle = isOffline ? "#ef4444" : isWarning ? "#f59e0b" : "#10b981";
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 8;
    ctx.fill();

    // 5. Holographic Label (Cyber Sentinel Style)
    ctx.font = "bold 11px system-ui";
    ctx.fillStyle = "#f8fafc";
    ctx.textAlign = "center";
    ctx.fillText(dev.name, pos.x, pos.y + 36);

    ctx.font = "9px monospace";
    ctx.fillStyle = isOffline ? "#ef4444" : isWarning ? "#f59e0b" : mainColor;
    ctx.fillText(isOffline ? "ALERT: OFFLINE" : dev.ip_address, pos.x, pos.y + 48);

    ctx.restore();
  }

  destroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }
}

window.NetGuardianCyber3DViewer = NetGuardianCyber3DViewer;
