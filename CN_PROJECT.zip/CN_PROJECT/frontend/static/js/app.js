// NetGuardian Real-Time SPA Architecture
// State Store, API Bridge, Real-Time Polling, SVG Topology, Charts, Modals, 18 Modules

const API_BASE = "";

// Global State
const state = {
  activeTab: "dashboard",
  user: JSON.parse(localStorage.getItem("netguardian_user")) || null,
  token: localStorage.getItem("netguardian_token") || null,
  loginForm: { username: "admin", password: "", error: "" },
  summary: {
    health_score: 98.4,
    total_devices: 7,
    active_devices: 7,
    offline_devices: 0,
    active_anomalies: 0,
    critical_alerts: 0,
    resolved_issues: 12,
    network_availability: 99.8
  },
  devices: [],
  selectedDevice: null,
  deviceConfig: null,
  metrics: [],
  anomalies: [],
  alerts: [],
  rcaList: [],
  incidents: [],
  predictions: [],
  resolutionLogs: [],
  protectionStatus: null,
  topology: { nodes: [], edges: [] },
  adminSettings: {},
  simulationScenario: "normal",
  notification: null
};

// API Client Helper
async function api(endpoint, method = "GET", body = null) {
  const headers = { "Content-Type": "application/json" };
  if (state.token) headers["Authorization"] = `Bearer ${state.token}`;
  try {
    const res = await fetch(API_BASE + endpoint, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: "Request failed" }));
      throw new Error(err.detail || "API Error");
    }
    return await res.json();
  } catch (e) {
    console.error("API error at " + endpoint + ":", e.message);
    throw e;
  }
}

// Show Toast Notification
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast-popup badge-${type === "success" ? "green" : type === "error" ? "red" : "blue"}`;
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 9999;
    padding: 14px 20px; border-radius: 8px; font-weight: 600; font-size: 0.85rem;
    box-shadow: 0 10px 25px rgba(0,0,0,0.5); backdrop-filter: blur(8px);
    display: flex; align-items: center; gap: 10px; transition: all 0.3s ease;
  `;
  toast.innerHTML = `<span>${type === "success" ? "✓" : "⚠"}</span> ${message}`;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Format Date / Time
function fmtTime(iso) {
  if (!iso) return "--";
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
function fmtDate(iso) {
  if (!iso) return "--";
  const d = new Date(iso);
  return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Navigation Handler
function navigate(tab, deviceId = null) {
  state.activeTab = tab;
  if (deviceId) {
    state.selectedDevice = state.devices.find(d => d.id === deviceId) || null;
  }
  render();
  if (tab === "3d-network") {
    setTimeout(init3DViewer, 50);
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// User Logout
function handleLogout() {
  localStorage.removeItem("netguardian_user");
  localStorage.removeItem("netguardian_token");
  state.user = null;
  state.token = null;
  render();
  showToast("Logged out successfully.", "info");
}

// User Login Form Handler
async function handleLogin(e) {
  e.preventDefault();
  const u = document.getElementById("loginUser").value.trim();
  const p = document.getElementById("loginPass").value.trim();
  const errBox = document.getElementById("loginError");
  errBox.style.display = "none";

  try {
    const res = await api("/api/auth/login", "POST", { username: u, password: p });
    state.user = res.user;
    state.token = res.access_token;
    localStorage.setItem("netguardian_user", JSON.stringify(res.user));
    localStorage.setItem("netguardian_token", res.access_token);
    state.activeTab = "dashboard";
    showToast(`Welcome back, ${res.user.full_name}!`, "success");
    await refreshAll();
  } catch (err) {
    errBox.style.display = "block";
    errBox.innerText = err.message || "Invalid username or password";
  }
}

// Initialize and Fetch All Engine Data
async function refreshAll() {
  if (!state.user) return;
  try {
    const [summary, devices, anomalies, alerts, rca, inc, logs, top, pred, settings] = await Promise.all([
      api("/api/dashboard/summary").catch(() => state.summary),
      api("/api/devices").catch(() => []),
      api("/api/anomalies").catch(() => []),
      api("/api/alerts").catch(() => []),
      api("/api/rca").catch(() => []),
      api("/api/incidents").catch(() => []),
      api("/api/resolution/logs").catch(() => []),
      api("/api/topology").catch(() => ({ nodes: [], edges: [] })),
      api("/api/predictions").catch(() => []),
      api("/api/admin/settings").catch(() => ({}))
    ]);

    state.summary = summary;
    state.devices = devices;
    state.anomalies = anomalies;
    state.alerts = alerts;
    state.rcaList = rca;
    state.incidents = inc;
    state.resolutionLogs = logs;
    state.topology = top;
    state.predictions = pred;
    state.adminSettings = settings;

    // Fetch recent metrics for active device or aggregate
    const metricsDevId = state.selectedDevice ? state.selectedDevice.id : (devices[0] ? devices[0].id : null);
    if (metricsDevId) {
      state.metrics = await api(`/api/metrics/recent?device_id=${metricsDevId}&limit=20`).catch(() => []);
    }

    if (state.activeTab === "3d-network" && viewer3DInstance) {
      viewer3DInstance.updateData(state.devices, state.topology.edges, state.metrics);
    } else if (state.activeTab !== "connect" && state.activeTab !== "config") {
      // Do not re-render DOM while user is actively filling out the Connect or Config form
      render();
    }
  } catch (err) {
    console.error("Polling refresh error:", err);
  }
}

// Auto-Refresh Poll every 3.5 seconds
setInterval(refreshAll, 3500);

// SVG Sparkline / Metric Chart Generator
function generateSvgLineChart(data, key, color = "#3b82f6", maxVal = null) {
  if (!data || data.length < 2) {
    return `<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#64748b;font-size:0.8rem;">Collecting real-time metrics...</div>`;
  }
  const vals = data.map(d => Number(d[key]) || 0);
  const min = 0;
  const max = maxVal || Math.max(...vals, 10);
  const w = 500;
  const h = 180;
  const pad = 24;

  const points = vals.map((v, i) => {
    const x = pad + (i / (vals.length - 1)) * (w - pad * 2);
    const y = (h - pad) - ((v - min) / (max - min)) * (h - pad * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");

  const lastVal = vals[vals.length - 1];

  return `
    <div style="position:relative;width:100%;height:100%;">
      <div style="position:absolute;top:6px;right:10px;font-size:0.82rem;font-weight:700;color:${color};">
        Current: ${lastVal.toFixed(1)}
      </div>
      <svg viewBox="0 0 ${w} ${h}" style="width:100%;height:100%;overflow:visible;">
        <defs>
          <linearGradient id="grad-${key}" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="${color}" stop-opacity="0.3"/>
            <stop offset="100%" stop-color="${color}" stop-opacity="0.0"/>
          </linearGradient>
        </defs>
        <line x1="${pad}" y1="${pad}" x2="${w - pad}" y2="${pad}" stroke="#1e293b" stroke-dasharray="3,3"/>
        <line x1="${pad}" y1="${h / 2}" x2="${w - pad}" y2="${h / 2}" stroke="#1e293b" stroke-dasharray="3,3"/>
        <line x1="${pad}" y1="${h - pad}" x2="${w - pad}" y2="${h - pad}" stroke="#334155"/>
        <text x="4" y="${pad + 4}" fill="#64748b" font-size="10">${max.toFixed(0)}</text>
        <text x="4" y="${h - pad}" fill="#64748b" font-size="10">0</text>
        <polygon points="${pad},${h - pad} ${points} ${w - pad},${h - pad}" fill="url(#grad-${key})"/>
        <polyline fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" points="${points}"/>
        ${vals.map((v, i) => {
          const x = pad + (i / (vals.length - 1)) * (w - pad * 2);
          const y = (h - pad) - ((v - min) / (max - min)) * (h - pad * 2);
          return `<circle cx="${x}" cy="${y}" r="3" fill="${color}"/>`;
        }).join("")}
      </svg>
    </div>
  `;
}

// Network Topology Interactive SVG Map
function renderTopologySvg() {
  const nodes = state.topology.nodes || [];
  const edges = state.topology.edges || [];

  if (!nodes.length) {
    return `<div style="text-align:center;padding:100px;color:#64748b;">No network topology mapped. Connect devices to see live graph.</div>`;
  }

  const posMap = {};
  const cx = 450;
  const cy = 250;
  
  const router = nodes.find(n => n.device_type === "Router");
  const sw = nodes.find(n => n.device_type === "Switch");
  const endpoints = nodes.filter(n => n.device_type !== "Router" && n.device_type !== "Switch");

  if (router) posMap[router.id] = { x: 120, y: cy };
  if (sw) posMap[sw.id] = { x: 380, y: cy };

  const angleStep = (2 * Math.PI) / Math.max(1, endpoints.length);
  endpoints.forEach((ep, idx) => {
    const angle = idx * angleStep - Math.PI / 2;
    posMap[ep.id] = {
      x: 680 + Math.cos(angle) * 160,
      y: cy + Math.sin(angle) * 160
    };
  });

  return `
    <svg viewBox="0 0 920 500" style="width:100%;height:100%;">
      <defs>
        <filter id="glow-green" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <filter id="glow-red" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#10192e" stroke-width="1"/>
      </pattern>
      <rect width="920" height="500" fill="url(#grid)" />

      ${edges.map(e => {
        const p1 = posMap[e.source_device_id] || { x: 200, y: 200 };
        const p2 = posMap[e.target_device_id] || { x: 400, y: 200 };
        const isDown = e.status !== "Up";
        return `
          <g>
            <line x1="${p1.x}" y1="${p1.y}" x2="${p2.x}" y2="${p2.y}" 
                  stroke="${isDown ? '#ef4444' : '#3b82f6'}" stroke-width="${isDown ? 3 : 2}" 
                  stroke-dasharray="${isDown ? '6,6' : 'none'}" opacity="${isDown ? 0.9 : 0.6}"/>
            <circle cx="${(p1.x + p2.x)/2}" cy="${(p1.y + p2.y)/2}" r="3" fill="${isDown ? '#ef4444' : '#60a5fa'}"/>
          </g>
        `;
      }).join("")}

      ${nodes.map(n => {
        const p = posMap[n.id] || { x: 400, y: 250 };
        const isOffline = n.reachability_status !== "Reachable" || n.status === "Connection Failed";
        const hasWarning = n.status === "Degraded";
        const color = isOffline ? "#ef4444" : hasWarning ? "#f59e0b" : "#10b981";
        const icon = n.device_type === "Router" ? "⌁" : n.device_type === "Switch" ? "⇄" : n.device_type === "Server" ? "▤" : "💻";

        return `
          <g class="topology-node" onclick="navigate('device-details', '${n.id}')" transform="translate(${p.x}, ${p.y})">
            <circle cx="0" cy="0" r="26" fill="${color}" fill-opacity="0.12" stroke="${color}" stroke-width="2" filter="${isOffline ? 'url(#glow-red)' : 'none'}"/>
            <circle cx="0" cy="0" r="18" fill="#0f172a" stroke="${color}" stroke-width="2"/>
            <text x="0" y="5" text-anchor="middle" fill="${color}" font-size="14" font-weight="bold">${icon}</text>
            <rect x="-60" y="28" width="120" height="20" rx="4" fill="#0b1120" stroke="#1e293b"/>
            <text x="0" y="42" text-anchor="middle" fill="#f8fafc" font-size="10.5" font-weight="600">${n.name}</text>
            <text x="0" y="58" text-anchor="middle" fill="#64748b" font-size="9">${n.ip_address}</text>
          </g>
        `;
      }).join("")}
    </svg>
  `;
}

// Simulation Control Bar for Steps 6, 7, 8, 9, 10
function renderScenarioBar() {
  return `
    <div style="background:#0b1120;border:1px solid #1e293b;border-radius:10px;padding:12px 18px;margin-bottom:24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:0.8rem;font-weight:700;color:#94a3b8;text-transform:uppercase;">⚡ Simulate Network Issues:</span>
        <button class="btn btn-sm ${state.simulationScenario === 'normal' ? 'btn-success' : 'btn-secondary'}" onclick="triggerScenario('normal')">Normal Baseline</button>
        <button class="btn btn-sm ${state.simulationScenario === 'connection_loss' ? 'btn-danger' : 'btn-secondary'}" onclick="triggerScenario('connection_loss')">Connection Loss</button>
        <button class="btn btn-sm ${state.simulationScenario === 'high_latency' ? 'btn-danger' : 'btn-secondary'}" onclick="triggerScenario('high_latency')">High Latency</button>
        <button class="btn btn-sm ${state.simulationScenario === 'packet_loss' ? 'btn-danger' : 'btn-secondary'}" onclick="triggerScenario('packet_loss')">High Packet Loss</button>
      </div>
      <div>
        <button class="btn btn-sm btn-primary" onclick="triggerRecoveryTest()">⚡ Step 9 & 10: Auto-Resolve & Verify Isolation</button>
      </div>
    </div>
  `;
}

async function triggerScenario(scenario) {
  state.simulationScenario = scenario;
  try {
    const res = await api("/api/simulation/inject", "POST", { scenario });
    showToast(res.message, scenario === "normal" ? "success" : "info");
    await refreshAll();
  } catch (e) {
    showToast(e.message, "error");
  }
}

async function triggerRecoveryTest() {
  if (state.incidents.length > 0) {
    const inc = state.incidents[0];
    try {
      const res = await api("/api/resolution/execute", "POST", {
        incident_id: inc.id,
        device_id: inc.device_id,
        action_name: inc.resolution_action || "Restart Local Monitoring Agent & Keepalive Service",
        mode: "Safe Auto Mode"
      });
      showToast(`Auto-Resolution: Target recovered! All peer devices verified healthy.`, "success");
      await refreshAll();
    } catch (e) {
      showToast(e.message, "error");
    }
  } else {
    // Inject connection loss then auto-resolve
    await triggerScenario("connection_loss");
    setTimeout(async () => {
      await refreshAll();
      if (state.incidents.length > 0) {
        const inc = state.incidents[0];
        await api("/api/resolution/execute", "POST", {
          incident_id: inc.id,
          device_id: inc.device_id,
          action_name: "Restart Local Monitoring Agent & Keepalive Service",
          mode: "Safe Auto Mode"
        });
        showToast("Auto-Resolution complete! Recovery & Device Isolation verified.", "success");
        await refreshAll();
      }
    }, 1500);
  }
}

// 1. Dashboard View
function renderDashboard() {
  const s = state.summary;
  const recentDevs = state.devices.slice(0, 6);
  const recentAlerts = state.alerts.slice(0, 5);

  return `
    ${renderScenarioBar()}

    <div class="grid-cards">
      <div class="card">
        <div class="card-header-flex">
          <span class="card-title-sm">Overall Network Health</span>
          <span class="badge-status ${s.health_score > 90 ? 'badge-green' : s.health_score > 70 ? 'badge-yellow' : 'badge-red'}">${s.health_score}%</span>
        </div>
        <div class="card-value" style="color:${s.health_score > 90 ? '#34d399' : s.health_score > 70 ? '#fbbf24' : '#f87171'};">
          ${s.health_score} <span class="card-unit">Score</span>
        </div>
        <div class="card-subtext">Overall autonomous stability metric</div>
      </div>

      <div class="card">
        <div class="card-header-flex">
          <span class="card-title-sm">Total Devices</span>
          <span class="badge-status badge-blue">${s.active_devices}/${s.total_devices} Online</span>
        </div>
        <div class="card-value">${s.total_devices} <span class="card-unit">Nodes</span></div>
        <div class="card-subtext">${s.offline_devices > 0 ? `<span style="color:#ef4444;">${s.offline_devices} Offline</span>` : 'All endpoints reachable'}</div>
      </div>

      <div class="card">
        <div class="card-header-flex">
          <span class="card-title-sm">Active Alerts</span>
          <span class="badge-status ${s.critical_alerts > 0 ? 'badge-red' : 'badge-green'}">${s.critical_alerts} Critical</span>
        </div>
        <div class="card-value" style="color:${s.critical_alerts > 0 ? '#ef4444' : '#f8fafc'};">${s.critical_alerts}</div>
        <div class="card-subtext">Active SLA violations</div>
      </div>

      <div class="card">
        <div class="card-header-flex">
          <span class="card-title-sm">Auto-Resolved</span>
          <span class="badge-status badge-green">Verified</span>
        </div>
        <div class="card-value" style="color:#10b981;">${s.resolved_issues} <span class="card-unit">Fixes</span></div>
        <div class="card-subtext">Device isolation verified</div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(360px, 1fr));gap:20px;margin-bottom:28px;">
      <div class="chart-box">
        <div class="card-header-flex">
          <span class="card-title-sm">Real-Time Latency (RTT)</span>
          <span class="badge-status badge-blue">Ping Probe</span>
        </div>
        <div style="flex:1;">
          ${generateSvgLineChart(state.metrics, "latency_ms", "#3b82f6", 120)}
        </div>
      </div>

      <div class="chart-box">
        <div class="card-header-flex">
          <span class="card-title-sm">Packet Loss Percentage</span>
          <span class="badge-status badge-red">Threshold Guard</span>
        </div>
        <div style="flex:1;">
          ${generateSvgLineChart(state.metrics, "packet_loss_pct", "#ef4444", 30)}
        </div>
      </div>

      <div class="chart-box">
        <div class="card-header-flex">
          <span class="card-title-sm">Bandwidth Utilization</span>
          <span class="badge-status badge-purple">Port Saturation</span>
        </div>
        <div style="flex:1;">
          ${generateSvgLineChart(state.metrics, "bandwidth_usage_pct", "#8b5cf6", 100)}
        </div>
      </div>

      <div class="chart-box">
        <div class="card-header-flex">
          <span class="card-title-sm">DNS Resolution Time</span>
          <span class="badge-status badge-cyan">Lookup Delay</span>
        </div>
        <div style="flex:1;">
          ${generateSvgLineChart(state.metrics, "dns_resolution_ms", "#06b6d4", 150)}
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:24px;margin-bottom:28px;">
      <div class="table-wrapper">
        <div class="table-header">
          <span class="table-title">Network Device Fleet</span>
          <button class="btn btn-sm btn-primary" onclick="navigate('connect')">+ Connect Device</button>
        </div>
        <table>
          <thead>
            <tr>
              <th>Device Name</th>
              <th>Type</th>
              <th>IP Address</th>
              <th>Status</th>
              <th>Reachability</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${recentDevs.map(d => `
              <tr>
                <td><strong>${d.name}</strong><br><span style="font-size:0.75rem;color:#64748b;">${d.location || 'HQ'}</span></td>
                <td><span class="badge-status badge-blue">${d.device_type}</span></td>
                <td><code>${d.ip_address}</code></td>
                <td><span class="badge-status ${d.status === 'Connected' ? 'badge-green' : 'badge-red'}">${d.status}</span></td>
                <td><span class="badge-status ${d.reachability_status === 'Reachable' ? 'badge-green' : 'badge-red'}">${d.reachability_status}</span></td>
                <td>
                  <button class="btn btn-sm btn-secondary" onclick="navigate('device-details', '${d.id}')">Inspect</button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>

      <div class="table-wrapper">
        <div class="table-header">
          <span class="table-title">Recent Alerts</span>
          <button class="btn btn-sm btn-secondary" onclick="navigate('alerts')">View All</button>
        </div>
        <table>
          <thead>
            <tr>
              <th>Device</th>
              <th>Problem</th>
              <th>Severity</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${recentAlerts.length ? recentAlerts.map(a => `
              <tr>
                <td><strong>${a.device_name}</strong></td>
                <td><span style="font-size:0.8rem;color:#f87171;">${a.problem}</span></td>
                <td><span class="badge-status ${a.severity === 'Critical' ? 'badge-red' : 'badge-yellow'}">${a.severity}</span></td>
                <td>
                  ${a.resolution_status === 'Resolved' 
                    ? `<span class="badge-status badge-green">Resolved</span>`
                    : `<button class="btn btn-sm btn-success" onclick="resolveAlertDirect('${a.id}', '${a.device_id}')">Fix</button>`}
                </td>
              </tr>
            `).join("") : `<tr><td colspan="4" style="text-align:center;color:#64748b;padding:30px;">All network parameters normal. No active alerts.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// 2 & 3. Connect Device Page
function renderConnectPage() {
  return `
    <div style="max-width:850px;margin:0 auto;">
      <div class="card" style="margin-bottom:24px;">
        <h2 style="font-size:1.25rem;font-weight:700;margin-bottom:6px;">Connect New Network Device</h2>
        <p style="color:#94a3b8;font-size:0.85rem;margin-bottom:20px;">
          Register a test device or physical equipment into autonomous monitoring.
        </p>

        <form id="connectDeviceForm" onsubmit="handleDeviceConnect(event)">
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Device Name *</label>
              <input type="text" id="devName" class="form-control" placeholder="e.g. Branch-Office-Test-PC" required>
            </div>

            <div class="form-group">
              <label class="form-label">Device Type *</label>
              <select id="devType" class="form-control" required>
                <option value="Desktop / Computer">Desktop / Computer</option>
                <option value="Router">Router</option>
                <option value="Switch">Switch</option>
                <option value="Server">Server</option>
                <option value="Laptop">Laptop</option>
                <option value="Access Point">Access Point</option>
                <option value="Network Printer">Network Printer</option>
                <option value="Other">Other network-connected device</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">IP Address *</label>
              <input type="text" id="devIp" class="form-control" placeholder="192.168.1.199" required>
            </div>

            <div class="form-group">
              <label class="form-label">Hostname</label>
              <input type="text" id="devHostname" class="form-control" placeholder="testpc.corp.lan">
            </div>

            <div class="form-group">
              <label class="form-label">Location / Department</label>
              <input type="text" id="devLocation" class="form-control" placeholder="Testing Lab A">
            </div>

            <div class="form-group">
              <label class="form-label">Monitoring Protocol</label>
              <select id="devProtocol" class="form-control">
                <option value="ICMP Ping">ICMP Ping</option>
                <option value="SNMP v2c/v3">SNMP v2c/v3</option>
                <option value="HTTP/HTTPS Health Check">HTTP/HTTPS Health Check</option>
                <option value="SSH-based diagnostics">SSH-based diagnostics</option>
                <option value="Agent-based monitoring">Agent-based monitoring</option>
              </select>
            </div>
          </div>

          <div class="form-group" style="display:flex;align-items:center;gap:10px;margin-top:16px;">
            <input type="checkbox" id="devIsSim" checked style="width:18px;height:18px;accent-color:#3b82f6;">
            <label for="devIsSim" style="font-size:0.85rem;color:#cbd5e1;cursor:pointer;">
              <strong>Test Device Mode (Simulation)</strong> - Recommended for safe testing without risking physical hardware.
            </label>
          </div>

          <div id="testConnResult" style="margin:16px 0;display:none;"></div>

          <div style="display:flex;gap:12px;margin-top:24px;">
            <button type="button" class="btn btn-secondary" onclick="testConnectionFromForm()">Test Connection</button>
            <button type="submit" class="btn btn-primary">Save & Register Device</button>
          </div>
        </form>
      </div>

      <div class="table-wrapper">
        <div class="table-header">
          <span class="table-title">Currently Registered Devices</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Type</th>
              <th>IP Address</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${state.devices.map(d => `
              <tr>
                <td><code>${d.id}</code></td>
                <td><strong>${d.name}</strong> ${d.is_simulation ? '<span class="badge-status badge-purple">Test Device</span>' : ''}</td>
                <td>${d.device_type}</td>
                <td><code>${d.ip_address}</code></td>
                <td><span class="badge-status ${d.status === 'Connected' ? 'badge-green' : 'badge-red'}">${d.status}</span></td>
                <td>
                  <button class="btn btn-sm btn-secondary" onclick="navigate('config', '${d.id}')">Configure</button>
                  <button class="btn btn-sm btn-danger" onclick="deleteDeviceDirect('${d.id}')">Delete</button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function testConnectionFromForm() {
  const ip = document.getElementById("devIp").value || "127.0.0.1";
  const isSim = document.getElementById("devIsSim").checked;
  const resultDiv = document.getElementById("testConnResult");
  resultDiv.style.display = "block";
  resultDiv.innerHTML = `<span style="color:#60a5fa;">Pinging host and verifying reachability...</span>`;

  try {
    const res = await api("/api/devices/test-connection", "POST", { ip_address: ip, is_simulation: isSim });
    resultDiv.innerHTML = `
      <div class="badge-status ${res.reachable ? 'badge-green' : 'badge-red'}" style="padding:8px 14px;border-radius:8px;">
        ${res.status} | Latency: ${res.latency_ms}ms | Loss: ${res.packet_loss_pct}% | ${res.message}
      </div>
    `;
  } catch (e) {
    resultDiv.innerHTML = `<div class="badge-status badge-red">${e.message}</div>`;
  }
}

async function handleDeviceConnect(e) {
  e.preventDefault();
  const payload = {
    name: document.getElementById("devName").value,
    device_type: document.getElementById("devType").value,
    ip_address: document.getElementById("devIp").value,
    hostname: document.getElementById("devHostname").value,
    location: document.getElementById("devLocation").value,
    protocol: document.getElementById("devProtocol").value,
    credentials: "",
    is_simulation: document.getElementById("devIsSim").checked
  };

  try {
    const res = await api("/api/devices/connect", "POST", payload);
    showToast(res.message, "success");
    await refreshAll();
    navigate("config", res.device_id);
  } catch (err) {
    showToast(err.message, "error");
  }
}

async function deleteDeviceDirect(devId) {
  if (!confirm("Are you sure you want to delete this device?")) return;
  try {
    const res = await api(`/api/devices/${devId}`, "DELETE");
    showToast(res.message, "info");
    await refreshAll();
  } catch (err) {
    showToast(err.message, "error");
  }
}

// 4. Configure Thresholds
function renderConfigPage(deviceId = null) {
  const targetId = deviceId || (state.selectedDevice ? state.selectedDevice.id : (state.devices[0] ? state.devices[0].id : null));
  const dev = state.devices.find(d => d.id === targetId) || state.devices[0];

  if (!dev) {
    return `<div style="text-align:center;padding:100px;color:#64748b;">No devices connected yet. Please connect a device first.</div>`;
  }

  return `
    <div style="max-width:850px;margin:0 auto;">
      <div class="card" style="margin-bottom:24px;">
        <div class="card-header-flex">
          <div>
            <h2 style="font-size:1.25rem;font-weight:700;">Configure Network Thresholds</h2>
            <p style="color:#94a3b8;font-size:0.82rem;">Configuring: <strong>${dev.name}</strong> (${dev.ip_address}) - ${dev.device_type}</p>
          </div>
          <select class="form-control" style="width:200px;" onchange="navigate('config', this.value)">
            ${state.devices.map(d => `<option value="${d.id}" ${d.id === dev.id ? 'selected' : ''}>${d.name}</option>`).join("")}
          </select>
        </div>

        <form onsubmit="handleSaveConfig(event, '${dev.id}')" style="margin-top:20px;">
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label">Latency Threshold - Normal (ms)</label>
              <input type="number" step="0.1" id="cfgLatNorm" class="form-control" value="20.0" required>
            </div>
            <div class="form-group">
              <label class="form-label">Latency Threshold - Max (ms)</label>
              <input type="number" step="0.1" id="cfgLatMax" class="form-control" value="50.0" required>
            </div>
            <div class="form-group">
              <label class="form-label">Packet Loss Threshold - Max (%)</label>
              <input type="number" step="0.1" id="cfgLossMax" class="form-control" value="1.5" required>
            </div>
            <div class="form-group">
              <label class="form-label">Jitter Threshold - Max (ms)</label>
              <input type="number" step="0.1" id="cfgJitterMax" class="form-control" value="10.0" required>
            </div>
            <div class="form-group">
              <label class="form-label">Connection Loss - Max Failed Checks</label>
              <input type="number" step="1" id="cfgFailsMax" class="form-control" value="2" required>
            </div>
            <div class="form-group">
              <label class="form-label">Bandwidth Critical Utilization (%)</label>
              <input type="number" step="1" id="cfgBwCrit" class="form-control" value="85" required>
            </div>
          </div>

          <div style="display:flex;justify-content:space-between;align-items:center;margin-top:24px;border-top:1px solid #1e293b;padding-top:18px;">
            <button type="button" class="btn btn-secondary" onclick="resetConfigDefaults()">Reset Defaults</button>
            <div style="display:flex;gap:12px;">
              <button type="button" class="btn btn-secondary" onclick="navigate('dashboard')">Cancel</button>
              <button type="submit" class="btn btn-primary">Save & Apply Thresholds</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  `;
}

async function handleSaveConfig(e, devId) {
  e.preventDefault();
  const payload = {
    latency_normal: parseFloat(document.getElementById("cfgLatNorm").value),
    latency_max: parseFloat(document.getElementById("cfgLatMax").value),
    packet_loss_max: parseFloat(document.getElementById("cfgLossMax").value),
    jitter_max: parseFloat(document.getElementById("cfgJitterMax").value),
    bandwidth_warning: 70.0,
    bandwidth_critical: parseFloat(document.getElementById("cfgBwCrit").value),
    connection_loss_max_fails: parseInt(document.getElementById("cfgFailsMax").value),
    dns_resolution_time_max: 100.0,
    monitoring_interval_sec: 3
  };

  try {
    const res = await api(`/api/devices/${devId}/config`, "POST", payload);
    showToast(res.message, "success");
    navigate("device-details", devId);
  } catch (err) {
    showToast(err.message, "error");
  }
}

function resetConfigDefaults() {
  document.getElementById("cfgLatNorm").value = "20.0";
  document.getElementById("cfgLatMax").value = "50.0";
  document.getElementById("cfgLossMax").value = "1.5";
  document.getElementById("cfgJitterMax").value = "10.0";
  document.getElementById("cfgFailsMax").value = "2";
  document.getElementById("cfgBwCrit").value = "85";
  showToast("Defaults loaded.", "info");
}

// 5. Device Details & Real-Time Monitoring Controls
function renderDeviceDetailsPage() {
  const dev = state.selectedDevice || state.devices[0];
  if (!dev) {
    return `<div style="text-align:center;padding:100px;color:#64748b;">Select a device to inspect.</div>`;
  }

  return `
    <div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;">${dev.name}</h2>
          <p style="color:#94a3b8;font-size:0.85rem;">${dev.ip_address} | ${dev.location || 'HQ'}</p>
        </div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-secondary" onclick="navigate('config', '${dev.id}')">Configure Thresholds</button>
          <button class="btn btn-secondary" onclick="runDeviceDiagnostic('${dev.id}')">Run Connection Test</button>
          ${dev.status === 'Connected' 
            ? `<button class="btn btn-danger" onclick="disconnectDeviceDirect('${dev.id}')">Stop Monitoring</button>` 
            : `<button class="btn btn-success" onclick="reconnectDeviceDirect('${dev.id}')">Start Monitoring</button>`}
        </div>
      </div>

      <div class="grid-cards" style="margin-bottom:24px;">
        <div class="card">
          <span class="card-title-sm">Device Type</span>
          <div class="card-value" style="font-size:1.2rem;margin-top:6px;">${dev.device_type}</div>
        </div>
        <div class="card">
          <span class="card-title-sm">Monitoring Status</span>
          <div class="card-value" style="font-size:1.2rem;margin-top:6px;color:${dev.status === 'Connected' ? '#10b981' : '#ef4444'};">
            ${dev.status === 'Connected' ? 'Online' : 'Offline'}
          </div>
        </div>
        <div class="card">
          <span class="card-title-sm">Reachability</span>
          <div class="card-value" style="font-size:1.2rem;margin-top:6px;color:${dev.reachability_status === 'Reachable' ? '#10b981' : '#ef4444'};">
            ${dev.reachability_status}
          </div>
        </div>
        <div class="card">
          <span class="card-title-sm">Failed Probes</span>
          <div class="card-value" style="font-size:1.2rem;margin-top:6px;">${dev.consecutive_failures || 0}</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px;">
        <div class="chart-box">
          <span class="card-title-sm">Live Latency (RTT)</span>
          <div style="flex:1;">${generateSvgLineChart(state.metrics, "latency_ms", "#3b82f6", 100)}</div>
        </div>
        <div class="chart-box">
          <span class="card-title-sm">Live Packet Loss (%)</span>
          <div style="flex:1;">${generateSvgLineChart(state.metrics, "packet_loss_pct", "#ef4444", 25)}</div>
        </div>
      </div>

      <div id="diagResult" style="margin-bottom:24px;display:none;"></div>
    </div>
  `;
}

async function runDeviceDiagnostic(devId) {
  const box = document.getElementById("diagResult");
  box.style.display = "block";
  box.innerHTML = `<span style="color:#60a5fa;">Running live ICMP probe...</span>`;

  try {
    const dev = state.devices.find(d => d.id === devId);
    const res = await api("/api/devices/test-connection", "POST", { ip_address: dev.ip_address, is_simulation: dev.is_simulation });
    box.innerHTML = `
      <div class="card" style="border-color:#3b82f6;">
        <h4 style="font-size:0.95rem;font-weight:700;color:#60a5fa;margin-bottom:8px;">Diagnostic Report for ${dev.name}</h4>
        <p style="font-size:0.85rem;color:#f8fafc;">Status: <strong>${res.status}</strong></p>
        <p style="font-size:0.85rem;color:#f8fafc;">Average RTT: <strong>${res.latency_ms} ms</strong></p>
        <p style="font-size:0.85rem;color:#f8fafc;">Packet Loss: <strong>${res.packet_loss_pct} %</strong></p>
        <p style="font-size:0.8rem;color:#94a3b8;margin-top:6px;">${res.message}</p>
      </div>
    `;
  } catch (e) {
    box.innerHTML = `<span style="color:#ef4444;">${e.message}</span>`;
  }
}

async function disconnectDeviceDirect(devId) {
  try {
    await api(`/api/devices/${devId}/disconnect`, "POST");
    showToast("Monitoring stopped for device.", "info");
    await refreshAll();
  } catch (e) {
    showToast(e.message, "error");
  }
}

async function reconnectDeviceDirect(devId) {
  try {
    await api(`/api/devices/${devId}/reconnect`, "POST");
    showToast("Monitoring started for device.", "success");
    await refreshAll();
  } catch (e) {
    showToast(e.message, "error");
  }
}

// 7. Alerts Page
function renderAlertsPage() {
  return `
    <div>
      <h2 style="font-size:1.35rem;font-weight:700;margin-bottom:6px;">Alerts & Event Logs</h2>
      <p style="color:#94a3b8;font-size:0.85rem;margin-bottom:24px;">Automatic threshold violations and connection loss events.</p>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Alert ID</th>
              <th>Device</th>
              <th>Problem</th>
              <th>Severity</th>
              <th>Detected Metric</th>
              <th>Root Cause</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${state.alerts.length ? state.alerts.map(a => `
              <tr>
                <td><code>${a.id}</code></td>
                <td><strong>${a.device_name}</strong></td>
                <td><span style="color:#f87171;font-weight:600;">${a.problem}</span></td>
                <td><span class="badge-status ${a.severity === 'Critical' ? 'badge-red' : 'badge-yellow'}">${a.severity}</span></td>
                <td>${a.current_metric || '--'}</td>
                <td>${a.probable_root_cause || '--'}</td>
                <td><span class="badge-status ${a.resolution_status === 'Resolved' ? 'badge-green' : 'badge-red'}">${a.resolution_status}</span></td>
                <td>
                  ${a.resolution_status === 'Resolved' ? `<span style="color:#94a3b8;font-size:0.8rem;">Resolved</span>` : `
                    <button class="btn btn-sm btn-success" onclick="resolveAlertDirect('${a.id}', '${a.device_id}')">Auto-Resolve</button>
                  `}
                </td>
              </tr>
            `).join("") : `<tr><td colspan="8" style="text-align:center;color:#64748b;padding:30px;">Zero active alerts. System healthy.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function resolveAlertDirect(alertId, deviceId) {
  try {
    await api(`/api/alerts/${alertId}/resolve`, "POST");
    await api("/api/resolution/execute", "POST", {
      incident_id: null,
      device_id: deviceId,
      action_name: "Restart Local Monitoring Agent & Keepalive Service",
      mode: "Safe Auto Mode"
    });
    showToast("Alert resolved and device recovered.", "success");
    await refreshAll();
  } catch (e) {
    showToast(e.message, "error");
  }
}

// 8. Root Cause Analysis Page
function renderRcaPage() {
  const rca = state.rcaList;
  return `
    <div>
      <h2 style="font-size:1.35rem;font-weight:700;margin-bottom:6px;">Root Cause Analysis (RCA)</h2>
      <p style="color:#94a3b8;font-size:0.85rem;margin-bottom:24px;">Correlates multi-metric anomalies with topology state to determine probable cause.</p>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Device</th>
              <th>Problem Detected</th>
              <th>Likely Root Cause</th>
              <th>Confidence</th>
              <th>Supporting Evidence</th>
              <th>Recommended Corrective Action</th>
            </tr>
          </thead>
          <tbody>
            ${rca.length ? rca.map(r => `
              <tr>
                <td>${fmtTime(r.created_at)}</td>
                <td><strong>${r.device_name}</strong></td>
                <td><span style="color:#f87171;font-weight:600;">${r.problem_detected}</span></td>
                <td><strong>${r.probable_root_cause}</strong></td>
                <td><span class="badge-status badge-blue">${(r.confidence_score * 100).toFixed(0)}%</span></td>
                <td style="max-width:280px;font-size:0.8rem;color:#cbd5e1;">${r.evidence}</td>
                <td><span style="color:#34d399;font-weight:600;font-size:0.82rem;">${r.recommended_solution}</span></td>
              </tr>
            `).join("") : `<tr><td colspan="7" style="text-align:center;color:#64748b;padding:30px;">No root cause records. Network operating optimally.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// 9. Auto-Resolution Page
function renderAutoResolutionPage() {
  const logs = state.resolutionLogs;
  const incs = state.incidents.filter(i => i.status !== "Resolved");

  return `
    <div style="margin-bottom:24px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;">Automated Problem Resolution Engine</h2>
          <p style="color:#94a3b8;font-size:0.85rem;">Device-specific targeted remediation, rollback safety, and recovery verification.</p>
        </div>
      </div>

      <div class="table-wrapper" style="margin-bottom:28px;">
        <div class="table-header">
          <span class="table-title">Incidents Requiring Resolution</span>
          <span class="badge-status ${incs.length > 0 ? 'badge-red' : 'badge-green'}">${incs.length} Pending</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Incident ID</th>
              <th>Target Device</th>
              <th>Problem</th>
              <th>Likely Root Cause</th>
              <th>Proposed Fix</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${incs.length ? incs.map(i => `
              <tr>
                <td><code>${i.id}</code></td>
                <td><strong>${i.device_name}</strong></td>
                <td><span style="color:#f87171;">${i.problem}</span></td>
                <td>${i.root_cause || 'Analyzing...'}</td>
                <td><span style="color:#60a5fa;font-weight:600;">${i.resolution_action || 'Restart Local Monitoring Agent & Keepalive Service'}</span></td>
                <td>
                  <button class="btn btn-sm btn-success" onclick="executeResolutionAction('${i.id}', '${i.device_id}', '${i.resolution_action}')">
                    Execute Fix (Target Only)
                  </button>
                </td>
              </tr>
            `).join("") : `<tr><td colspan="6" style="text-align:center;color:#64748b;padding:30px;">All network devices operating smoothly. No pending remediation tasks.</td></tr>`}
          </tbody>
        </table>
      </div>

      <div class="table-wrapper">
        <div class="table-header">
          <span class="table-title">Resolution Audit History & Rollback Controls</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Device</th>
              <th>Action Attempted</th>
              <th>Side Effects</th>
              <th>Status</th>
              <th>Recovery Verified</th>
              <th>Rollback</th>
            </tr>
          </thead>
          <tbody>
            ${logs.length ? logs.map(l => `
              <tr>
                <td>${fmtTime(l.started_at)}</td>
                <td><strong>${l.device_name}</strong></td>
                <td>${l.action_name}</td>
                <td>
                  <span class="badge-status ${l.side_effects_detected === 0 ? 'badge-green' : 'badge-red'}">
                    ${l.side_effects_detected === 0 ? '0 Peer Impact' : `${l.side_effects_detected} impacted`}
                  </span>
                </td>
                <td><span class="badge-status ${l.status === 'Resolved' ? 'badge-green' : 'badge-yellow'}">${l.status}</span></td>
                <td><span class="badge-status ${l.verified_recovery ? 'badge-green' : 'badge-red'}">${l.verified_recovery ? '✓ Passed' : 'Pending'}</span></td>
                <td>
                  ${l.rolled_back ? `<span style="font-size:0.75rem;color:#94a3b8;">Rolled Back</span>` : `
                    <button class="btn btn-sm btn-secondary" onclick="rollbackDirect('${l.id}')">Rollback</button>
                  `}
                </td>
              </tr>
            `).join("") : `<tr><td colspan="7" style="text-align:center;color:#64748b;padding:30px;">No resolution logs recorded yet.</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function executeResolutionAction(incId, devId, actionName) {
  try {
    const res = await api("/api/resolution/execute", "POST", {
      incident_id: incId,
      device_id: devId,
      action_name: actionName || "Restart Local Monitoring Agent & Keepalive Service",
      mode: "Safe Auto Mode"
    });
    showToast(`Recovery verified on target device! All peers 100% online.`, "success");
    await refreshAll();
  } catch (e) {
    showToast(e.message, "error");
  }
}

async function rollbackDirect(logId) {
  try {
    const res = await api(`/api/resolution/${logId}/rollback`, "POST");
    showToast(res.message, "info");
    await refreshAll();
  } catch (e) {
    showToast(e.message, "error");
  }
}

// 10. Device Isolation & Protection Status Page
function renderProtectionPage() {
  const peers = state.devices;
  return `
    <div>
      <h2 style="font-size:1.35rem;font-weight:700;margin-bottom:6px;">Device Isolation & Protection Verification</h2>
      <p style="color:#94a3b8;font-size:0.85rem;margin-bottom:24px;">Confirms that faults or fixes on one device do not disrupt peer devices.</p>

      <div class="card" style="border-color:#10b981;margin-bottom:24px;">
        <h3 style="color:#34d399;font-size:1.1rem;font-weight:700;margin-bottom:8px;">✓ Device Isolation Protocol Active</h3>
        <p style="font-size:0.85rem;color:#cbd5e1;line-height:1.6;">
          Total Registered Fleet: <strong>${peers.length} devices</strong>.<br>
          Isolated Failures: <strong>Scope-guarded to target device only</strong>.<br>
          Peer Health Monitoring: <strong>Continuous (100% Online)</strong>.<br>
          Side-Effects Detected: <strong>0</strong>.
        </p>
      </div>

      <div class="table-wrapper">
        <div class="table-header">
          <span class="table-title">Peer Device Verification Fleet</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Device Name</th>
              <th>IP Address</th>
              <th>Type</th>
              <th>Status</th>
              <th>Reachability</th>
              <th>Isolation State</th>
            </tr>
          </thead>
          <tbody>
            ${peers.map(d => `
              <tr>
                <td><strong>${d.name}</strong></td>
                <td><code>${d.ip_address}</code></td>
                <td>${d.device_type}</td>
                <td><span class="badge-status ${d.status === 'Connected' ? 'badge-green' : 'badge-red'}">${d.status}</span></td>
                <td><span class="badge-status ${d.reachability_status === 'Reachable' ? 'badge-green' : 'badge-red'}">${d.reachability_status}</span></td>
                <td><span class="badge-status badge-blue">✓ Isolated & Protected</span></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// Topology Page
function renderTopologyPage() {
  return `
    <div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;">Network Topology Visualization</h2>
          <p style="color:#94a3b8;font-size:0.85rem;">Live map displaying device dependencies and reachability.</p>
        </div>
      </div>
      <div class="topology-container">
        ${renderTopologySvg()}
      </div>
    </div>
  `;
}

// Reports Page
function renderReportsPage() {
  return `
    <div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
        <div>
          <h2 style="font-size:1.35rem;font-weight:700;">Reports & Telemetry Analytics</h2>
          <p style="color:#94a3b8;font-size:0.85rem;">Export historical performance and incident resolutions.</p>
        </div>
        <div style="display:flex;gap:12px;">
          <a href="/api/reports/export?format=csv" class="btn btn-primary" download>Export CSV Report</a>
          <button class="btn btn-secondary" onclick="window.print()">Print Report</button>
        </div>
      </div>

      <div class="grid-cards" style="margin-bottom:24px;">
        <div class="card">
          <span class="card-title-sm">Total Fleet</span>
          <div class="card-value">${state.summary.total_devices}</div>
        </div>
        <div class="card">
          <span class="card-title-sm">Total Incidents</span>
          <div class="card-value">${state.incidents.length}</div>
        </div>
        <div class="card">
          <span class="card-title-sm">Auto-Remediations</span>
          <div class="card-value" style="color:#10b981;">${state.summary.resolved_issues}</div>
        </div>
        <div class="card">
          <span class="card-title-sm">Availability SLA</span>
          <div class="card-value" style="color:#34d399;">${state.summary.network_availability}%</div>
        </div>
      </div>
    </div>
  `;
}

// Login Screen View
function renderLoginPage() {
  return `
    <div style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:#090d16;padding:20px;">
      <div class="card" style="width:100%;max-width:420px;padding:32px;box-shadow:0 12px 36px rgba(0,0,0,0.6);">
        <div style="text-align:center;margin-bottom:28px;">
          <div style="width:50px;height:50px;margin:0 auto 12px;background:linear-gradient(135deg,#3b82f6,#6366f1);border-radius:12px;display:flex;align-items:center;justify-content:center;box-shadow:0 0 20px rgba(59,130,246,0.5);">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
            </svg>
          </div>
          <h2 style="font-size:1.4rem;font-weight:700;color:#f8fafc;">NetGuardian</h2>
          <p style="font-size:0.82rem;color:#94a3b8;margin-top:4px;">Intelligent Network Monitoring & Auto-Resolution</p>
        </div>

        <div id="loginError" class="badge-status badge-red" style="display:none;width:100%;margin-bottom:16px;padding:8px 12px;border-radius:6px;text-align:center;"></div>

        <form onsubmit="handleLogin(event)">
          <div class="form-group">
            <label class="form-label">Username</label>
            <input type="text" id="loginUser" class="form-control" value="admin" required placeholder="admin">
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" id="loginPass" class="form-control" value="admin123" required placeholder="••••••••">
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;margin-top:12px;padding:10px;">
            Login to NetGuardian
          </button>
        </form>

        <div style="margin-top:20px;text-align:center;font-size:0.75rem;color:#64748b;">
          Default Demonstration Credentials: <code>admin</code> / <code>admin123</code>
        </div>
      </div>
    </div>
  `;
}

// 11. 3D Cyber Sentinel Network Visualization Page
let viewer3DInstance = null;

function render3DNetworkPage() {
  const selected = state.selectedDevice;

  return `
    <div>
      <!-- Header Toolbar Matching Cyber Sentinel Reference Image -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:12px;">
        <div style="display:flex;align-items:center;gap:12px;">
          <h2 style="font-size:1.35rem;font-weight:700;background:linear-gradient(135deg, #00f0ff, #d946ef);-webkit-background-clip:text;-webkit-text-fill-color:transparent;">
            LIVE NETWORK TOPOLOGY (CYBER SENTINEL 3D)
          </h2>
          <span class="badge-status badge-green" style="font-size:0.75rem;padding:4px 10px;">
            <span class="pulse-dot"></span> Real-Time Status Active
          </span>
        </div>

        <!-- 3D Controls Toolbar with Interactive Link Connector Button -->
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
          <button id="btnConnectMode" class="btn btn-sm ${viewer3DInstance && viewer3DInstance.isConnectMode ? 'btn-primary' : 'btn-secondary'}" 
                  onclick="toggleLinkConnectMode()" style="border-color:#00f0ff;color:#00f0ff;font-weight:700;">
            ⚡ Link Device Connection
          </button>

          <input type="text" id="viewerSearch" class="form-control" style="width:150px;padding:6px 10px;font-size:0.8rem;" 
                 placeholder="Search node..." oninput="handle3DSearch(this.value)">

          <select id="viewerFilter" class="form-control" style="width:130px;padding:6px 10px;font-size:0.8rem;" 
                  onchange="handle3DFilter(this.value)">
            <option value="ALL">All Nodes</option>
            <option value="ONLINE">Online Only</option>
            <option value="WARNING">Degraded/Warning</option>
            <option value="OFFLINE">Offline / Fault</option>
          </select>

          <button class="btn btn-sm btn-secondary" onclick="reset3DCamera()" title="Reset Camera">⟲ Reset View</button>
          <button class="btn btn-sm btn-secondary" onclick="toggle3DFullscreen()" title="Full Screen">⛶ Fullscreen</button>
        </div>
      </div>

      <!-- Cyber Sentinel Connection Prompt Banner (When Link Mode is Active) -->
      <div id="connectPromptBanner" style="display:none;background:#0c1729;border:1px solid #00f0ff;border-radius:8px;padding:10px 16px;margin-bottom:14px;color:#38bdf8;font-size:0.85rem;font-weight:600;">
        ⚡ Interactive Linking Mode: Click the source device, then click the target device to establish a new 3D connection line.
      </div>

      <!-- 3D Interactive Stage and Drawer -->
      <div style="display:grid;grid-template-columns:1fr ${selected ? '360px' : '0px'};gap:18px;transition:all 0.3s ease;">
        <div id="viewer3dContainer" style="height:620px;background:#050811;border:1px solid #1e293b;border-radius:14px;position:relative;overflow:hidden;box-shadow:inset 0 0 50px rgba(0,0,0,0.9);">
          <div style="position:absolute;top:14px;left:18px;z-index:10;pointer-events:none;">
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="pulse-dot" style="background:#00f0ff;box-shadow:0 0 10px #00f0ff;"></span>
              <span style="font-size:0.75rem;font-weight:700;color:#00f0ff;text-transform:uppercase;letter-spacing:1px;">CYBER SENTINEL 3D TOPOLOGY</span>
            </div>
            <div style="font-size:0.7rem;color:#64748b;margin-top:4px;">Drag to Pan • Scroll to Zoom • Click Node to Inspect & Configure • Click Link Button to Connect Nodes</div>
          </div>
        </div>

        <!-- Floating Device Info Panel (If a 3D Node is clicked) -->
        ${selected ? `
          <div class="card" style="height:620px;overflow-y:auto;border-color:#00f0ff;box-shadow:0 8px 30px rgba(0,0,0,0.5);">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;border-bottom:1px solid #1e293b;padding-bottom:10px;">
              <h3 style="font-size:1rem;font-weight:700;color:#00f0ff;">Device Inspector</h3>
              <button class="btn btn-sm btn-secondary" onclick="close3DInspector()" style="padding:2px 8px;">✕</button>
            </div>

            <div style="margin-bottom:16px;">
              <div style="font-size:1.15rem;font-weight:700;color:#f8fafc;">${selected.name}</div>
              <div style="font-size:0.8rem;color:#00f0ff;font-family:monospace;">${selected.ip_address}</div>
            </div>

            <div class="form-grid" style="grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
              <div style="background:#090d16;padding:10px;border-radius:8px;border:1px solid #1e293b;">
                <span class="card-title-sm" style="font-size:0.68rem;">Status</span>
                <div style="margin-top:4px;">
                  <span class="badge-status ${selected.status === 'Connected' ? 'badge-green' : 'badge-red'}">
                    ${selected.status === 'Connected' ? 'Online' : 'Offline'}
                  </span>
                </div>
              </div>

              <div style="background:#090d16;padding:10px;border-radius:8px;border:1px solid #1e293b;">
                <span class="card-title-sm" style="font-size:0.68rem;">Reachability</span>
                <div style="margin-top:4px;">
                  <span class="badge-status ${selected.reachability_status === 'Reachable' ? 'badge-green' : 'badge-red'}">
                    ${selected.reachability_status}
                  </span>
                </div>
              </div>
            </div>

            <div style="background:#090d16;padding:12px;border-radius:8px;border:1px solid #1e293b;margin-bottom:16px;">
              <div style="font-size:0.75rem;font-weight:700;color:#94a3b8;margin-bottom:8px;text-transform:uppercase;">Live Telemetry & Thresholds</div>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;margin-bottom:6px;">
                <span style="color:#64748b;">Device Type:</span>
                <span style="font-weight:600;color:#f8fafc;">${selected.device_type}</span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;margin-bottom:6px;">
                <span style="color:#64748b;">Location:</span>
                <span>${selected.location || 'HQ'}</span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;margin-bottom:6px;">
                <span style="color:#64748b;">Protocol:</span>
                <span>${selected.protocol}</span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:0.82rem;margin-bottom:6px;">
                <span style="color:#64748b;">Failed Checks:</span>
                <span style="color:${selected.consecutive_failures > 0 ? '#ef4444' : '#10b981'};font-weight:bold;">${selected.consecutive_failures || 0}</span>
              </div>
            </div>

            <!-- Action Controls -->
            <div style="display:flex;flex-direction:column;gap:8px;margin-top:16px;">
              <button class="btn btn-sm ${selected.status === 'Connected' ? 'btn-danger' : 'btn-success'}" 
                      onclick="toggleMonitoring3D('${selected.id}')">
                ${selected.status === 'Connected' ? 'Stop Monitoring' : 'Start Monitoring'}
              </button>
              <button class="btn btn-sm btn-secondary" onclick="simulateLoss3D('${selected.id}')">
                Simulate Connection Loss (Fault)
              </button>
              <button class="btn btn-sm btn-primary" onclick="navigate('config', '${selected.id}')">
                Edit Thresholds
              </button>
            </div>
          </div>
        ` : ''}
      </div>
    </div>
  `;
}

function init3DViewer() {
  if (state.activeTab !== "3d-network") return;
  const container = document.getElementById("viewer3dContainer");
  if (!container) return;

  if (viewer3DInstance) {
    viewer3DInstance.destroy();
  }

  viewer3DInstance = new NetGuardianCyber3DViewer("viewer3dContainer", {
    onSelect: (dev) => {
      state.selectedDevice = dev;
      render();
      init3DViewer();
    },
    onConnectPrompt: (msg) => {
      const banner = document.getElementById("connectPromptBanner");
      if (banner) {
        banner.style.display = "block";
        banner.innerText = "⚡ " + msg;
      }
    },
    onEstablishLink: async (srcId, tgtId) => {
      try {
        const res = await api("/api/topology/connect", "POST", {
          source_device_id: srcId,
          target_device_id: tgtId,
          link_type: "Ethernet 1Gbps"
        });
        showToast(res.message, "success");
        const banner = document.getElementById("connectPromptBanner");
        if (banner) banner.style.display = "none";
        await refreshAll();
        init3DViewer();
      } catch (e) {
        showToast(e.message, "error");
      }
    }
  });

  viewer3DInstance.updateData(state.devices, state.topology.edges, state.metrics);
  if (state.selectedDevice) {
    viewer3DInstance.selectedDevice = state.selectedDevice;
  }
}

function toggleLinkConnectMode() {
  if (!viewer3DInstance) return;
  const isNowActive = !viewer3DInstance.isConnectMode;
  viewer3DInstance.setConnectMode(isNowActive);
  const banner = document.getElementById("connectPromptBanner");
  const btn = document.getElementById("btnConnectMode");

  if (isNowActive) {
    if (banner) banner.style.display = "block";
    if (btn) btn.className = "btn btn-sm btn-primary";
    showToast("Click Device A, then click Device B to connect in 3D.", "info");
  } else {
    if (banner) banner.style.display = "none";
    if (btn) btn.className = "btn btn-sm btn-secondary";
  }
}

function handle3DSearch(q) {
  if (viewer3DInstance) {
    viewer3DInstance.searchQuery = q;
  }
}

function handle3DFilter(f) {
  if (viewer3DInstance) {
    viewer3DInstance.statusFilter = f;
  }
}

function reset3DCamera() {
  if (viewer3DInstance) {
    viewer3DInstance.resetView();
  }
}

function toggle3DFullscreen() {
  const container = document.getElementById("viewer3dContainer");
  if (!container) return;
  if (!document.fullscreenElement) {
    container.requestFullscreen().catch(() => {});
  } else {
    document.exitFullscreen().catch(() => {});
  }
}

function close3DInspector() {
  state.selectedDevice = null;
  render();
  init3DViewer();
}

async function toggleMonitoring3D(devId) {
  const dev = state.devices.find(d => d.id === devId);
  if (!dev) return;
  try {
    if (dev.status === "Connected") {
      await api(`/api/devices/${devId}/disconnect`, "POST");
      showToast("Monitoring stopped for " + dev.name, "info");
    } else {
      await api(`/api/devices/${devId}/reconnect`, "POST");
      showToast("Monitoring resumed for " + dev.name, "success");
    }
    await refreshAll();
    init3DViewer();
  } catch (e) {
    showToast(e.message, "error");
  }
}

async function simulateLoss3D(devId) {
  try {
    const res = await api("/api/simulation/inject", "POST", { scenario: "connection_loss", device_id: devId });
    showToast(res.message, "info");
    await refreshAll();
    init3DViewer();
  } catch (e) {
    showToast(e.message, "error");
  }
}

// Main Frame Renderer
function render() {
  const root = document.getElementById("root");
  if (!root) return;

  if (!state.user) {
    root.innerHTML = renderLoginPage();
    return;
  }

  const currentTab = state.activeTab;

  let pageContent = "";
  if (currentTab === "dashboard") pageContent = renderDashboard();
  else if (currentTab === "connect") pageContent = renderConnectPage();
  else if (currentTab === "config") pageContent = renderConfigPage(state.selectedDevice ? state.selectedDevice.id : null);
  else if (currentTab === "3d-network") pageContent = render3DNetworkPage();
  else if (currentTab === "auto-resolution") pageContent = renderAutoResolutionPage();
  else if (currentTab === "device-details") pageContent = renderDeviceDetailsPage();
  else if (currentTab === "topology") pageContent = renderTopologyPage();
  else if (currentTab === "rca") pageContent = renderRcaPage();
  else if (currentTab === "alerts") pageContent = renderAlertsPage();
  else if (currentTab === "reports") pageContent = renderReportsPage();
  else if (currentTab === "protection") pageContent = renderProtectionPage();

  root.innerHTML = `
    <div class="app-container">
      <aside class="sidebar">
        <div class="brand">
          <div class="brand-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
            </svg>
          </div>
          <div class="brand-title">NetGuardian</div>
          <span class="brand-badge">2.0</span>
        </div>

        <nav class="nav-menu">
          <div class="nav-section-title">Core Operations</div>
          <a class="nav-item ${currentTab === 'dashboard' ? 'active' : ''}" onclick="navigate('dashboard')">
            <span>📊</span> Dashboard
          </a>
          <a class="nav-item ${currentTab === 'connect' ? 'active' : ''}" onclick="navigate('connect')">
            <span>🔌</span> Connect Devices
          </a>
          <a class="nav-item ${currentTab === 'config' ? 'active' : ''}" onclick="navigate('config')">
            <span>⚙</span> Configure Thresholds
          </a>
          <a class="nav-item ${currentTab === 'topology' ? 'active' : ''}" onclick="navigate('topology')">
            <span>🕸</span> Network Topology
          </a>
          <a class="nav-item ${currentTab === '3d-network' ? 'active' : ''}" onclick="navigate('3d-network')">
            <span>🌐</span> 3D Network View
          </a>

          <div class="nav-section-title">Intelligence & Auto-Fix</div>
          <a class="nav-item ${currentTab === 'alerts' ? 'active' : ''}" onclick="navigate('alerts')">
            <span>🔔</span> Alerts & Events
            ${state.alerts.filter(a => a.resolution_status !== 'Resolved').length > 0 
              ? `<span class="badge">${state.alerts.filter(a => a.resolution_status !== 'Resolved').length}</span>` : ''}
          </a>
          <a class="nav-item ${currentTab === 'rca' ? 'active' : ''}" onclick="navigate('rca')">
            <span>🔍</span> Root Cause Analysis
          </a>
          <a class="nav-item ${currentTab === 'auto-resolution' ? 'active' : ''}" onclick="navigate('auto-resolution')">
            <span>⚡</span> Auto Resolution
          </a>
          <a class="nav-item ${currentTab === 'protection' ? 'active' : ''}" onclick="navigate('protection')">
            <span>🛡</span> Device Isolation
          </a>
          <a class="nav-item ${currentTab === 'reports' ? 'active' : ''}" onclick="navigate('reports')">
            <span>📑</span> Reports & Export
          </a>
        </nav>

        <div class="sidebar-footer">
          <div class="user-avatar">${(state.user.username || "AD").slice(0, 2).toUpperCase()}</div>
          <div class="user-info">
            <div class="user-name">${state.user.full_name || state.user.username}</div>
            <div class="user-role">${state.user.role || 'admin'}</div>
          </div>
          <button class="btn btn-sm btn-secondary" onclick="handleLogout()" title="Logout" style="padding:4px 8px;font-size:0.75rem;">⏻</button>
        </div>
      </aside>

      <main class="main-wrapper">
        <header class="top-header">
          <div class="header-left">
            <h1 class="header-title">${currentTab.toUpperCase().replace("-", " ")}</h1>
            <span class="header-subtitle">Intelligent Network Monitoring & Auto-Resolution System</span>
          </div>

          <div class="header-actions">
            <div class="scenario-pill" onclick="navigate('auto-resolution')">
              <div class="pulse-dot"></div>
              <span>Auto Resolution: Active</span>
            </div>
            <button class="btn btn-sm btn-secondary" onclick="refreshAll()">⟳ Refresh</button>
          </div>
        </header>

        <div class="page-container">
          ${pageContent}
        </div>
      </main>
    </div>
  `;
}

// Initial Boot
document.addEventListener("DOMContentLoaded", () => {
  render();
  refreshAll();
});
