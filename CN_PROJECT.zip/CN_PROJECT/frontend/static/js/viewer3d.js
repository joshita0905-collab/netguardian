/**
 * NetGuardian 3D WebGL Interactive Topology Engine
 * Features:
 * - Central NetGuardian Server Node with radiant core rings
 * - Specialized 3D geometric node representations for Router, Switch, Server, Desktop, Laptop, Mobile, Access Point, Printer
 * - Animated glowing pulses and data packets travelling along connection lines
 * - Dynamic color transitions: Green (Normal), Yellow (High Latency/Degraded), Red (Broken/Disconnected)
 * - Complete camera controls: Orbit Rotate, Dolly Zoom, Pan, Camera Reset, Fullscreen
 * - Click-to-select raycast with instant floating telemetry drawer and live actions
 * - Real-time filtering (Online, Offline, Warning) and Search
 */

class NetGuardian3DViewer {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.options = options;
    this.devices = [];
    this.links = [];
    this.selectedDevice = null;
    this.searchQuery = "";
    this.statusFilter = "ALL"; // ALL, ONLINE, OFFLINE, WARNING

    // Camera & Orbit state
    this.camera = {
      radius: 48,
      theta: Math.PI / 4,
      phi: Math.PI / 3,
      target: [0, 0, 0],
      eye: [0, 0, 48],
      up: [0, 1, 0],
      fov: (45 * Math.PI) / 180,
      near: 0.1,
      far: 1000
    };

    // Animation & Packet state
    this.packets = [];
    this.animTime = 0;
    this.isDragging = false;
    this.isPanning = false;
    this.lastMouse = { x: 0, y: 0 };

    this.initCanvas();
    this.bindEvents();
    this.animate = this.animate.bind(this);
    this.animationFrameId = requestAnimationFrame(this.animate);
  }

  initCanvas() {
    this.container.innerHTML = "";
    this.container.style.position = "relative";
    this.container.style.overflow = "hidden";
    this.container.style.userSelect = "none";

    this.canvas = document.createElement("canvas");
    this.canvas.style.width = "100%";
    this.canvas.style.height = "100%";
    this.canvas.style.display = "block";
    this.container.appendChild(this.canvas);

    this.ctx = this.canvas.getContext("2d");
    this.resize();
  }

  resize() {
    if (!this.container || !this.canvas) return;
    const rect = this.container.getBoundingClientRect();
    this.width = rect.width || 800;
    this.height = rect.height || 550;
    this.canvas.width = this.width * window.devicePixelRatio;
    this.canvas.height = this.height * window.devicePixelRatio;
    this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }

  updateData(devices, links, metrics = []) {
    this.devices = devices || [];
    this.links = links || [];
    this.metrics = metrics || [];
    this.layoutNodes();
  }

  layoutNodes() {
    // Center node is the NetGuardian Core Monitoring Server at (0, 0, 0)
    const count = this.devices.length;
    if (count === 0) return;

    // Arrange nodes in 3D double rings / spiral orbit around Central Server
    const radiusInner = 18;
    const radiusOuter = 28;

    this.devices.forEach((dev, idx) => {
      // Determine orbital ring
      const isCore = dev.device_type === "Router" || dev.device_type === "Switch";
      const r = isCore ? radiusInner : radiusOuter;
      const angle = (idx / count) * Math.PI * 2 + (isCore ? 0 : Math.PI / count);
      const elevation = isCore ? Math.sin(idx * 2) * 3 : Math.cos(idx * 1.5) * 5;

      dev.pos3d = [
        Math.cos(angle) * r,
        elevation,
        Math.sin(angle) * r
      ];

      // Assign initial packet if none
      if (!this.packets.some(p => p.devId === dev.id)) {
        this.packets.push({
          devId: dev.id,
          t: Math.random(),
          speed: 0.35 + Math.random() * 0.25
        });
      }
    });
  }

  computeMatrices() {
    const c = this.camera;
    // Calculate eye position in spherical coords
    c.eye = [
      c.target[0] + c.radius * Math.sin(c.phi) * Math.sin(c.theta),
      c.target[1] + c.radius * Math.cos(c.phi),
      c.target[2] + c.radius * Math.sin(c.phi) * Math.cos(c.theta)
    ];

    const matView = new Mat4().lookAt(c.eye, c.target, c.up);
    const aspect = this.width / Math.max(1, this.height);
    const matProj = new Mat4().perspective(c.fov, aspect, c.near, c.far);
    this.viewProj = matProj.multiply(matView);
  }

  bindEvents() {
    window.addEventListener("resize", () => this.resize());

    // Mouse drag rotate / pan
    this.canvas.addEventListener("mousedown", (e) => {
      if (e.button === 0) this.isDragging = true;
      if (e.button === 2) this.isPanning = true;
      this.lastMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener("mousemove", (e) => {
      if (!this.isDragging && !this.isPanning) return;
      const dx = e.clientX - this.lastMouse.x;
      const dy = e.clientY - this.lastMouse.y;

      if (this.isDragging) {
        this.camera.theta -= dx * 0.007;
        this.camera.phi = Math.max(0.1, Math.min(Math.PI - 0.1, this.camera.phi - dy * 0.007));
      } else if (this.isPanning) {
        const factor = this.camera.radius * 0.0015;
        this.camera.target[0] -= dx * factor;
        this.camera.target[1] += dy * factor;
      }
      this.lastMouse = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener("mouseup", () => {
      this.isDragging = false;
      this.isPanning = false;
    });

    this.canvas.addEventListener("contextmenu", (e) => e.preventDefault());

    // Zoom
    this.canvas.addEventListener("wheel", (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY * 0.04;
      this.camera.radius = Math.max(10, Math.min(120, this.camera.radius + zoomFactor));
    }, { passive: false });

    // Click Raycast Selection
    this.canvas.addEventListener("click", (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      let closest = null;
      let minDistance = 24; // Pixel threshold hit test

      this.devices.forEach(dev => {
        if (!dev.proj2d) return;
        const d = Math.hypot(dev.proj2d.x - mouseX, dev.proj2d.y - mouseY);
        if (d < minDistance) {
          minDistance = d;
          closest = dev;
        }
      });

      this.selectDevice(closest);
    });
  }

  selectDevice(dev) {
    this.selectedDevice = dev;
    if (this.options.onSelect) {
      this.options.onSelect(dev);
    }
  }

  resetCamera() {
    this.camera.radius = 48;
    this.camera.theta = Math.PI / 4;
    this.camera.phi = Math.PI / 3;
    this.camera.target = [0, 0, 0];
  }

  animate(time) {
    this.animTime = time * 0.001;
    this.render();
    this.animationFrameId = requestAnimationFrame(this.animate);
  }

  render() {
    const ctx = this.ctx;
    if (!ctx) return;

    this.computeMatrices();

    // Clear background
    ctx.fillStyle = "#070b14";
    ctx.fillRect(0, 0, this.width, this.height);

    // Draw background 3D coordinate grid
    this.renderGrid(ctx);

    // Project Central Server at (0, 0, 0)
    const centerProj = new Mat4().projectVector([0, 0, 0], this.viewProj, this.width, this.height);

    // Project all devices
    const visibleNodes = [];
    this.devices.forEach(dev => {
      if (!dev.pos3d) return;

      // Filter check
      if (this.statusFilter === "ONLINE" && dev.reachability_status !== "Reachable") return;
      if (this.statusFilter === "OFFLINE" && dev.reachability_status === "Reachable") return;
      if (this.statusFilter === "WARNING" && dev.status !== "Degraded") return;
      if (this.searchQuery && !dev.name.toLowerCase().includes(this.searchQuery.toLowerCase()) && !dev.ip_address.includes(this.searchQuery)) return;

      const p2d = new Mat4().projectVector(dev.pos3d, this.viewProj, this.width, this.height);
      if (p2d) {
        dev.proj2d = p2d;
        visibleNodes.push(dev);
      }
    });

    // Sort visible nodes by depth (painter's algorithm)
    visibleNodes.sort((a, b) => b.proj2d.depth - a.proj2d.depth);

    // 1. Draw glowing connection lines from Central Server to all nodes
    if (centerProj) {
      visibleNodes.forEach(dev => {
        this.renderConnectionLine(ctx, centerProj, dev);
      });
    }

    // 2. Draw Central NetGuardian Core Server
    if (centerProj) {
      this.renderCentralCore(ctx, centerProj);
    }

    // 3. Draw Device 3D Nodes
    visibleNodes.forEach(dev => {
      this.renderDeviceNode(ctx, dev);
    });
  }

  renderGrid(ctx) {
    // Subtle 3D plane grid at Y = -6
    ctx.strokeStyle = "rgba(30, 41, 59, 0.4)";
    ctx.lineWidth = 1;
    const gridRange = 36;
    const step = 6;

    for (let x = -gridRange; x <= gridRange; x += step) {
      const p1 = new Mat4().projectVector([x, -6, -gridRange], this.viewProj, this.width, this.height);
      const p2 = new Mat4().projectVector([x, -6, gridRange], this.viewProj, this.width, this.height);
      if (p1 && p2) {
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    }

    for (let z = -gridRange; z <= gridRange; z += step) {
      const p1 = new Mat4().projectVector([-gridRange, -6, z], this.viewProj, this.width, this.height);
      const p2 = new Mat4().projectVector([gridRange, -6, z], this.viewProj, this.width, this.height);
      if (p1 && p2) {
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    }
  }

  renderConnectionLine(ctx, center, dev) {
    const isOffline = dev.reachability_status !== "Reachable" || dev.status === "Connection Failed";
    const isWarning = dev.status === "Degraded";

    let strokeColor = "#10b981"; // Green
    let glowColor = "rgba(16, 185, 129, 0.4)";

    if (isOffline) {
      strokeColor = "#ef4444"; // Red
      glowColor = "rgba(239, 68, 68, 0.4)";
    } else if (isWarning) {
      strokeColor = "#f59e0b"; // Yellow/Orange
      glowColor = "rgba(245, 158, 11, 0.4)";
    }

    // Line drawing
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(center.x, center.y);
    ctx.lineTo(dev.proj2d.x, dev.proj2d.y);

    if (isOffline) {
      // Broken/dashed line representing connection break
      ctx.setLineDash([8, 8]);
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 2;
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 8;
      ctx.stroke();
    } else {
      ctx.setLineDash([]);
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 2.2;
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 10;
      ctx.stroke();

      // Animate travelling data packets along the line
      const packet = this.packets.find(p => p.devId === dev.id);
      if (packet) {
        packet.t = (packet.t + 0.015 * packet.speed) % 1.0;
        const px = center.x + (dev.proj2d.x - center.x) * packet.t;
        const py = center.y + (dev.proj2d.y - center.y) * packet.t;

        ctx.beginPath();
        ctx.arc(px, py, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = "#ffffff";
        ctx.shadowColor = "#38bdf8";
        ctx.shadowBlur = 12;
        ctx.fill();
      }
    }
    ctx.restore();
  }

  renderCentralCore(ctx, p) {
    ctx.save();
    const t = this.animTime;
    const pulseRadius = 18 + Math.sin(t * 3) * 3;

    // Glowing shield rings
    ctx.beginPath();
    ctx.arc(p.x, p.y, pulseRadius + 10, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(59, 130, 246, 0.35)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    ctx.stroke();

    // Central Sphere
    const grad = ctx.createRadialGradient(p.x - 4, p.y - 4, 2, p.x, p.y, 20);
    grad.addColorStop(0, "#93c5fd");
    grad.addColorStop(0.5, "#3b82f6");
    grad.addColorStop(1, "#1e3a8a");

    ctx.beginPath();
    ctx.arc(p.x, p.y, 18, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.shadowColor = "#3b82f6";
    ctx.shadowBlur = 20;
    ctx.fill();

    // Label
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 11px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("NetGuardian Core", p.x, p.y + 32);
    ctx.fillStyle = "#60a5fa";
    ctx.font = "9px monospace";
    ctx.fillText("127.0.0.1 (Server)", p.x, p.y + 44);

    ctx.restore();
  }

  renderDeviceNode(ctx, dev) {
    const p = dev.proj2d;
    const isOffline = dev.reachability_status !== "Reachable" || dev.status === "Connection Failed";
    const isWarning = dev.status === "Degraded";
    const isSelected = this.selectedDevice && this.selectedDevice.id === dev.id;

    let baseColor = isOffline ? "#ef4444" : isWarning ? "#f59e0b" : "#10b981";
    let lightColor = isOffline ? "#fca5a5" : isWarning ? "#fde68a" : "#6ee7b7";
    let icon = "💻";
    const dType = dev.device_type || "";

    if (dType === "Router") icon = "⌁";
    else if (dType === "Switch") icon = "⇄";
    else if (dType === "Server") icon = "▤";
    else if (dType === "Laptop") icon = "💻";
    else if (dType === "Access Point") icon = "📶";
    else if (dType === "Network Printer") icon = "🖨";
    else if (dType.includes("Mobile")) icon = "📱";

    ctx.save();

    // Selection Ring
    if (isSelected) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 26 + Math.sin(this.animTime * 6) * 2, 0, Math.PI * 2);
      ctx.strokeStyle = "#38bdf8";
      ctx.lineWidth = 2.5;
      ctx.shadowColor = "#38bdf8";
      ctx.shadowBlur = 14;
      ctx.stroke();
    }

    // 3D Node Body (Geometric Diamond or Hexagon depending on device type)
    if (dType === "Router" || dType === "Switch") {
      // Diamond for infrastructure nodes
      const sz = 16;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - sz);
      ctx.lineTo(p.x + sz, p.y);
      ctx.lineTo(p.x, p.y + sz);
      ctx.lineTo(p.x - sz, p.y);
      ctx.closePath();
      ctx.fillStyle = "#0f172a";
      ctx.strokeStyle = baseColor;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = baseColor;
      ctx.shadowBlur = 12;
      ctx.fill();
      ctx.stroke();
    } else {
      // Circle Sphere for endpoints
      ctx.beginPath();
      ctx.arc(p.x, p.y, 14, 0, Math.PI * 2);
      ctx.fillStyle = "#0f172a";
      ctx.strokeStyle = baseColor;
      ctx.lineWidth = 2;
      ctx.shadowColor = baseColor;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.stroke();
    }

    // Device Icon inside node
    ctx.fillStyle = lightColor;
    ctx.font = "bold 11px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(icon, p.x, p.y);

    // Device Name & Status Cardlet
    ctx.font = "bold 10px system-ui";
    ctx.fillStyle = "#f8fafc";
    ctx.fillText(dev.name, p.x, p.y + 24);

    ctx.font = "9px monospace";
    ctx.fillStyle = isOffline ? "#ef4444" : isWarning ? "#f59e0b" : "#34d399";
    const statusText = isOffline ? "● OFFLINE" : isWarning ? "▲ WARNING" : "● ONLINE";
    ctx.fillText(statusText, p.x, p.y + 35);

    ctx.restore();
  }

  destroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
  }
}

window.NetGuardian3DViewer = NetGuardian3DViewer;
