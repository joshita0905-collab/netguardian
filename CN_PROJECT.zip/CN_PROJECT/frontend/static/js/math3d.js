/**
 * NetGuardian 3D WebGL Vector & Matrix Math Library
 * Standalone, robust 3D math engine supporting Vector3, Matrix4, Quaternion, Euler, and Raycasting
 */
class Mat4 {
  constructor() {
    this.elements = new Float32Array([
      1, 0, 0, 0,
      0, 1, 0, 0,
      0, 0, 1, 0,
      0, 0, 0, 1
    ]);
  }

  identity() {
    const te = this.elements;
    te[0] = 1; te[4] = 0; te[8] = 0; te[12] = 0;
    te[1] = 0; te[5] = 1; te[9] = 0; te[13] = 0;
    te[2] = 0; te[6] = 0; te[10] = 1; te[14] = 0;
    te[3] = 0; te[7] = 0; te[11] = 0; te[15] = 1;
    return this;
  }

  perspective(fovyRad, aspect, near, far) {
    const f = 1.0 / Math.tan(fovyRad / 2);
    const nf = 1 / (near - far);
    const te = this.elements;
    te[0] = f / aspect; te[4] = 0; te[8] = 0; te[12] = 0;
    te[1] = 0; te[5] = f; te[9] = 0; te[13] = 0;
    te[2] = 0; te[6] = 0; te[10] = (far + near) * nf; te[14] = (2 * far * near) * nf;
    te[3] = 0; te[7] = 0; te[11] = -1; te[15] = 0;
    return this;
  }

  lookAt(eye, center, up) {
    let z0 = eye[0] - center[0];
    let z1 = eye[1] - center[1];
    let z2 = eye[2] - center[2];
    let len = 1 / Math.hypot(z0, z1, z2);
    z0 *= len; z1 *= len; z2 *= len;

    let x0 = up[1] * z2 - up[2] * z1;
    let x1 = up[2] * z0 - up[0] * z2;
    let x2 = up[0] * z1 - up[1] * z0;
    len = Math.hypot(x0, x1, x2);
    if (!len) { x0 = 0; x1 = 0; x2 = 0; } else { len = 1 / len; x0 *= len; x1 *= len; x2 *= len; }

    let y0 = z1 * x2 - z2 * x1;
    let y1 = z2 * x0 - z0 * x2;
    let y2 = z0 * x1 - z1 * x0;
    len = Math.hypot(y0, y1, y2);
    if (!len) { y0 = 0; y1 = 0; y2 = 0; } else { len = 1 / len; y0 *= len; y1 *= len; y2 *= len; }

    const te = this.elements;
    te[0] = x0; te[4] = x1; te[8] = x2; te[12] = -(x0 * eye[0] + x1 * eye[1] + x2 * eye[2]);
    te[1] = y0; te[5] = y1; te[9] = y2; te[13] = -(y0 * eye[0] + y1 * eye[1] + y2 * eye[2]);
    te[2] = z0; te[6] = z1; te[10] = z2; te[14] = -(z0 * eye[0] + z1 * eye[1] + z2 * eye[2]);
    te[3] = 0; te[7] = 0; te[11] = 0; te[15] = 1;
    return this;
  }

  multiply(b) {
    const ae = this.elements;
    const be = b.elements;
    const te = new Float32Array(16);

    for (let i = 0; i < 4; i++) {
      const a0 = ae[i], a1 = ae[i + 4], a2 = ae[i + 8], a3 = ae[i + 12];
      te[i] = a0 * be[0] + a1 * be[1] + a2 * be[2] + a3 * be[3];
      te[i + 4] = a0 * be[4] + a1 * be[5] + a2 * be[6] + a3 * be[7];
      te[i + 8] = a0 * be[8] + a1 * be[9] + a2 * be[10] + a3 * be[11];
      te[i + 12] = a0 * be[12] + a1 * be[13] + a2 * be[14] + a3 * be[15];
    }
    this.elements = te;
    return this;
  }

  projectVector(v, viewProjMatrix, width, height) {
    const m = viewProjMatrix.elements;
    const x = v[0], y = v[1], z = v[2];
    const w = x * m[3] + y * m[7] + z * m[11] + m[15];
    if (w <= 0.0001) return null; // Behind camera
    const ndcX = (x * m[0] + y * m[4] + z * m[8] + m[12]) / w;
    const ndcY = (x * m[1] + y * m[5] + z * m[9] + m[13]) / w;
    return {
      x: (ndcX * 0.5 + 0.5) * width,
      y: (-(ndcY * 0.5) + 0.5) * height,
      depth: w
    };
  }
}

window.Mat4 = Mat4;
