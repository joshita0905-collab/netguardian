import json
import datetime
from typing import Dict, Any, List, Set
from app.database import get_db

class ImpactPredictionEngine:
    """
    Graph-based network topology analyzer that computes downstream transitive closure
    and calculates blast radius if a node or link fails.
    """
    def predict_impact(self, failing_device_id: str) -> dict:
        conn = get_db()
        cursor = conn.cursor()
        
        # Load devices & links
        devices = {row["id"]: dict(row) for row in cursor.execute("SELECT * FROM devices").fetchall()}
        links = [dict(row) for row in cursor.execute("SELECT * FROM network_links").fetchall()]
        conn.close()

        if failing_device_id not in devices:
            return {
                "predicted_impact": "Target device not found in topology",
                "affected_devices": "[]",
                "affected_services": "[]",
                "impact_severity": "Low",
                "confidence": 0.5,
                "preventive_recommendation": "Verify topology edge configuration."
            }

        target = devices[failing_device_id]
        
        # Build adjacency graph
        adj: Dict[str, List[str]] = {d_id: [] for d_id in devices}
        for l in links:
            s, t = l["source_device_id"], l["target_device_id"]
            if s in adj and t in adj:
                adj[s].append(t)
                adj[t].append(s)

        # Transitive downstream traversal if target is a core infrastructure element (Router / Switch)
        visited: Set[str] = set()
        affected_device_ids: List[str] = []
        affected_services: List[str] = []
        
        # If Router or Switch fails, downstream endpoints lose connectivity
        if target["device_type"] in ["Router", "Switch"]:
            # Traverse reachable nodes starting from neighbors, excluding core root if applicable
            queue = [neighbor for neighbor in adj.get(failing_device_id, [])]
            for n in queue:
                if n != failing_device_id and n in devices:
                    visited.add(n)
                    affected_device_ids.append(n)
            
            # Additional downstream
            for d_id in affected_device_ids:
                dev = devices.get(d_id, {})
                d_type = dev.get("device_type", "")
                if d_type == "Server":
                    affected_services.extend(["Database Cluster", "ERP Web App", "Internal Active Directory"])
                elif d_type == "Access Point":
                    affected_services.append("Corporate WiFi Zone (SSID: CorpNet)")
                elif d_type == "Network Printer":
                    affected_services.append("Network Print Spooler")

            if target["device_type"] == "Router":
                affected_services.extend(["External Internet Gateway", "Inter-VLAN Routing", "Site-to-Site VPN"])
                severity = "Critical"
                confidence = 0.95
                impact_text = f"Total subnet partition: {len(affected_device_ids)} downstream nodes and critical external gateway services disconnected."
                rec = "Switch upstream traffic immediately to Secondary Redundant Core Gateway (VRRP/HSRP failover)."
            else: # Switch
                affected_services.extend(["Departmental LAN Switching", "Local Broadcast Domain"])
                severity = "High"
                confidence = 0.90
                impact_text = f"Switch port outage isolates {len(affected_device_ids)} connected hosts in department {target.get('location', 'General')}."
                rec = "Enable Spanning-Tree alternate port or migrate patch cables to standby distribution switch."
        else:
            # Endpoint or server failure
            affected_device_ids = [target["id"]]
            if target["device_type"] == "Server":
                affected_services.append(f"Application Services on {target['name']}")
                severity = "Medium"
                confidence = 0.85
                impact_text = f"Service degradation isolated to {target['name']} ({target['ip_address']}). Zero upstream impact on routers/switches."
                rec = "Redirect inbound load balancer traffic away from this backend server."
            else:
                affected_services.append(f"Workstation Connectivity ({target['name']})")
                severity = "Low"
                confidence = 0.90
                impact_text = f"Single client endpoint isolated. Surrounding topology unaffected."
                rec = "Diagnose local endpoint network adapter and DHCP configuration."

        affected_names = [devices[did]["name"] for did in affected_device_ids if did in devices]

        return {
            "predicted_impact": impact_text,
            "affected_devices": json.dumps(affected_names),
            "affected_services": json.dumps(list(set(affected_services))),
            "impact_severity": severity,
            "confidence": confidence,
            "preventive_recommendation": rec
        }

impact_engine = ImpactPredictionEngine()
