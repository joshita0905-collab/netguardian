import sqlite3
import json
import os
import datetime
from typing import List, Dict, Any, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "netguardian.db")

def get_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    # 1. Users
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'network_admin',
        created_at TEXT NOT NULL,
        last_login TEXT
    )
    ''')

    # 2. Devices
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS devices (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        device_type TEXT NOT NULL,
        ip_address TEXT NOT NULL,
        hostname TEXT,
        location TEXT,
        protocol TEXT NOT NULL DEFAULT 'ICMP Ping',
        credentials TEXT,
        is_simulation INTEGER NOT NULL DEFAULT 1,
        status TEXT NOT NULL DEFAULT 'Connected',
        reachability_status TEXT NOT NULL DEFAULT 'Reachable',
        consecutive_failures INTEGER NOT NULL DEFAULT 0,
        last_seen TEXT,
        created_at TEXT NOT NULL
    )
    ''')

    # 3. Device Configurations & Default Thresholds
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS device_configurations (
        device_id TEXT PRIMARY KEY,
        latency_normal REAL DEFAULT 35.0,
        latency_max REAL DEFAULT 100.0,
        packet_loss_max REAL DEFAULT 2.5,
        jitter_max REAL DEFAULT 15.0,
        bandwidth_warning REAL DEFAULT 75.0,
        bandwidth_critical REAL DEFAULT 90.0,
        connection_loss_max_fails INTEGER DEFAULT 3,
        connection_loss_duration_sec INTEGER DEFAULT 15,
        availability_min REAL DEFAULT 98.0,
        http_response_time_max REAL DEFAULT 500.0,
        dns_resolution_time_max REAL DEFAULT 120.0,
        connection_failure_rate_max REAL DEFAULT 5.0,
        monitoring_interval_sec INTEGER DEFAULT 4,
        configured_capacity_mbps REAL DEFAULT 1000.0,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (device_id) REFERENCES devices (id)
    )
    ''')

    # 4. Network Links (Topology Edges)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS network_links (
        id TEXT PRIMARY KEY,
        source_device_id TEXT NOT NULL,
        target_device_id TEXT NOT NULL,
        link_type TEXT NOT NULL DEFAULT 'Ethernet 10Gbps',
        status TEXT NOT NULL DEFAULT 'Up',
        bandwidth_capacity_mbps REAL DEFAULT 1000.0,
        latency_penalty_ms REAL DEFAULT 1.0,
        packet_loss_penalty REAL DEFAULT 0.0,
        created_at TEXT NOT NULL
    )
    ''')

    # 5. Network Metrics (Time-series table)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS network_metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        latency_ms REAL NOT NULL,
        packet_loss_pct REAL NOT NULL,
        jitter_ms REAL NOT NULL,
        upload_mbps REAL NOT NULL,
        download_mbps REAL NOT NULL,
        bandwidth_usage_pct REAL NOT NULL,
        availability_pct REAL NOT NULL,
        http_response_ms REAL NOT NULL,
        dns_resolution_ms REAL NOT NULL,
        throughput_mbps REAL NOT NULL,
        connection_failure_rate REAL NOT NULL,
        is_reachable INTEGER NOT NULL,
        source TEXT NOT NULL DEFAULT 'simulated',
        FOREIGN KEY (device_id) REFERENCES devices (id)
    )
    ''')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_metrics_device_time ON network_metrics (device_id, timestamp)')

    # 6. Anomalies (Isolation Forest & Threshold Detections)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS anomalies (
        id TEXT PRIMARY KEY,
        device_id TEXT NOT NULL,
        device_name TEXT NOT NULL,
        device_ip TEXT NOT NULL,
        anomaly_type TEXT NOT NULL,
        metric_name TEXT NOT NULL,
        current_value REAL NOT NULL,
        expected_value REAL NOT NULL,
        severity TEXT NOT NULL,
        detection_time TEXT NOT NULL,
        description TEXT NOT NULL,
        probable_cause TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Active',
        FOREIGN KEY (device_id) REFERENCES devices (id)
    )
    ''')

    # 7. Root Cause Analysis
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS root_cause_analyses (
        id TEXT PRIMARY KEY,
        incident_id TEXT,
        device_id TEXT NOT NULL,
        problem_detected TEXT NOT NULL,
        probable_root_cause TEXT NOT NULL,
        evidence TEXT NOT NULL,
        related_metrics TEXT NOT NULL,
        confidence_score REAL NOT NULL,
        recommended_solution TEXT NOT NULL,
        is_confirmed INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
    )
    ''')

    # 8. Impact Predictions (Graph Topology Based)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS impact_predictions (
        id TEXT PRIMARY KEY,
        trigger_device_id TEXT NOT NULL,
        predicted_impact TEXT NOT NULL,
        affected_devices TEXT NOT NULL,
        affected_services TEXT NOT NULL,
        impact_severity TEXT NOT NULL,
        confidence REAL NOT NULL,
        preventive_recommendation TEXT NOT NULL,
        created_at TEXT NOT NULL
    )
    ''')

    # 9. Alerts
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS alerts (
        id TEXT PRIMARY KEY,
        device_id TEXT NOT NULL,
        device_name TEXT NOT NULL,
        device_ip TEXT NOT NULL,
        problem TEXT NOT NULL,
        severity TEXT NOT NULL,
        current_metric REAL,
        configured_threshold REAL,
        probable_root_cause TEXT,
        recommended_fix TEXT,
        detected_time TEXT NOT NULL,
        resolution_status TEXT NOT NULL DEFAULT 'Unresolved',
        acknowledged INTEGER NOT NULL DEFAULT 0,
        acknowledged_by TEXT,
        acknowledged_at TEXT
    )
    ''')

    # 10. Incidents
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS incidents (
        id TEXT PRIMARY KEY,
        device_id TEXT NOT NULL,
        device_name TEXT NOT NULL,
        problem TEXT NOT NULL,
        severity TEXT NOT NULL,
        root_cause TEXT,
        impact_prediction TEXT,
        resolution_action TEXT,
        status TEXT NOT NULL DEFAULT 'Open',
        detection_time TEXT NOT NULL,
        resolution_time TEXT,
        target_device_id TEXT,
        isolated_device_id TEXT
    )
    ''')

    # 11. Resolution Actions & Logs (Safety, Audit, Rollback)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS resolution_logs (
        id TEXT PRIMARY KEY,
        incident_id TEXT,
        device_id TEXT NOT NULL,
        action_name TEXT NOT NULL,
        mode TEXT NOT NULL,
        status TEXT NOT NULL,
        parameters TEXT,
        backup_state TEXT,
        side_effects_detected INTEGER DEFAULT 0,
        rolled_back INTEGER DEFAULT 0,
        started_at TEXT NOT NULL,
        completed_at TEXT,
        verified_recovery INTEGER DEFAULT 0,
        verification_details TEXT,
        log_message TEXT
    )
    ''')

    # 12. System Settings & Protection
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS system_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    ''')

    # Seed Admin User if none exists
    cursor.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
    if cursor.fetchone()[0] == 0:
        now = datetime.datetime.utcnow().isoformat()
        import hashlib
        # default password 'admin123'
        pwd_hash = hashlib.sha256('admin123'.encode('utf-8')).hexdigest()
        cursor.execute('''
        INSERT INTO users (id, username, email, password_hash, full_name, role, created_at)
        VALUES ('usr_admin_1', 'admin', 'admin@netguardian.io', ?, 'Global Network Admin', 'admin', ?)
        ''', (pwd_hash, now))

    # Seed Default Settings
    default_settings = {
        "auto_resolution_mode": "Approval Mode",  # Manual Mode, Approval Mode, Safe Auto Mode
        "monitoring_frequency_sec": "4",
        "anomaly_sensitivity": "0.1",
        "connection_loss_threshold_probes": "3",
        "device_protection_enabled": "true",
        "alert_notification_sound": "true",
        "approved_recovery_actions": json.dumps([
            "Flush Local DNS Cache & Switch Failover Resolver",
            "Clear Interface Buffer & Traffic Shaping QoS",
            "Local Interface Soft Reset & Rebind DHCP",
            "Re-route Traffic via Redundant Switch Link",
            "Restart Local Monitoring Agent & Keepalive Service"
        ])
    }
    for k, v in default_settings.items():
        cursor.execute("INSERT OR IGNORE INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)",
                       (k, v, datetime.datetime.utcnow().isoformat()))

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully.")
