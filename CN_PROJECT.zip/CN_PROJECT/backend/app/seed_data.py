import datetime
from app.database import get_db

def seed_initial_topology():
    conn = get_db()
    cursor = conn.cursor()

    # Check if devices already exist
    cursor.execute("SELECT COUNT(*) FROM devices")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return

    now = datetime.datetime.now(datetime.timezone.utc).isoformat()

    # Default Devices
    sample_devices = [
        ("dev_r1", "Core-Router-R1", "Router", "192.168.1.1", "r1.netguardian.corp", "Data Center Rack A", "SNMP v3", 1, "Connected", "Reachable", 0, now, now),
        ("dev_sw1", "Dist-Switch-SW1", "Switch", "192.168.1.2", "sw1.netguardian.corp", "IDF Room 101", "SNMP v2c", 1, "Connected", "Reachable", 0, now, now),
        ("dev_srv1", "App-Server-SRV1", "Server", "192.168.1.10", "srv1.netguardian.corp", "Data Center Rack B", "HTTP/HTTPS", 1, "Connected", "Reachable", 0, now, now),
        ("dev_srv2", "Database-SRV2", "Server", "192.168.1.11", "db1.netguardian.corp", "Data Center Rack B", "SSH-based", 1, "Connected", "Reachable", 0, now, now),
        ("dev_ap1", "Floor2-AccessPoint", "Access Point", "192.168.1.50", "ap-fl2.netguardian.corp", "Engineering Floor 2", "SNMP v2c", 1, "Connected", "Reachable", 0, now, now),
        ("dev_pc1", "Dev-Workstation-01", "Desktop / Computer", "192.168.1.101", "ws-01.netguardian.corp", "Eng Bay 4", "ICMP Ping", 1, "Connected", "Reachable", 0, now, now),
        ("dev_prn1", "Finance-LaserPrinter", "Network Printer", "192.168.1.75", "prn-fin.netguardian.corp", "Finance Suite", "ICMP Ping", 1, "Connected", "Reachable", 0, now, now)
    ]

    for d in sample_devices:
        cursor.execute('''
        INSERT INTO devices (id, name, device_type, ip_address, hostname, location, protocol, is_simulation, status, reachability_status, consecutive_failures, last_seen, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', d)

        # Config
        cursor.execute('''
        INSERT INTO device_configurations (device_id, latency_normal, latency_max, packet_loss_max, jitter_max, bandwidth_warning, bandwidth_critical, connection_loss_max_fails, updated_at)
        VALUES (?, 25.0, 80.0, 2.5, 12.0, 75.0, 90.0, 3, ?)
        ''', (d[0], now))

    # Topology Links (Core Router -> Switch -> Endpoints)
    sample_links = [
        ("link_1", "dev_r1", "dev_sw1", "Fiber 10Gbps Uplink", "Up", 10000.0, 0.5, 0.0, now),
        ("link_2", "dev_sw1", "dev_srv1", "Cat6 1Gbps Ethernet", "Up", 1000.0, 0.8, 0.0, now),
        ("link_3", "dev_sw1", "dev_srv2", "Cat6 1Gbps Ethernet", "Up", 1000.0, 0.8, 0.0, now),
        ("link_4", "dev_sw1", "dev_ap1", "PoE+ 1Gbps Ethernet", "Up", 1000.0, 1.2, 0.0, now),
        ("link_5", "dev_sw1", "dev_pc1", "Cat5e 1Gbps Ethernet", "Up", 1000.0, 1.5, 0.0, now),
        ("link_6", "dev_sw1", "dev_prn1", "Fast Ethernet 100Mbps", "Up", 100.0, 2.0, 0.0, now)
    ]

    for l in sample_links:
        cursor.execute('''
        INSERT INTO network_links (id, source_device_id, target_device_id, link_type, status, bandwidth_capacity_mbps, latency_penalty_ms, packet_loss_penalty, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', l)

    conn.commit()
    conn.close()
