import threading
import time
import datetime
import random
import json
from typing import Dict, Any, List, Optional
from app.database import get_db
from app.prober import ping_host, http_probe, dns_probe
from app.anomaly_engine import anomaly_detector
from app.rca_engine import rca_engine
from app.impact_engine import impact_engine

class MonitoringEngine:
    def __init__(self):
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self.fault_injections: Dict[str, Dict[str, Any]] = {}
        self.lock = threading.Lock()

    def set_device_fault(self, device_id: str, fault_type: str, severity: str = "High"):
        with self.lock:
            self.fault_injections[device_id] = {
                "type": fault_type,
                "severity": severity,
                "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat()
            }

    def clear_device_fault(self, device_id: str):
        with self.lock:
            if device_id in self.fault_injections:
                del self.fault_injections[device_id]

    def clear_all_faults(self):
        with self.lock:
            self.fault_injections.clear()

    def start(self):
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self.thread.start()

    def stop(self):
        self.running = False

    def _monitor_loop(self):
        while self.running:
            try:
                self._run_monitoring_cycle()
            except Exception as e:
                print(f"[MonitoringEngine Error] {e}")
            time.sleep(4) # Run probe cycle every 4 seconds

    def _run_monitoring_cycle(self):
        conn = get_db()
        cursor = conn.cursor()

        # Fetch devices and configs
        devices = [dict(row) for row in cursor.execute("SELECT * FROM devices WHERE status != 'Disconnected'").fetchall()]
        if not devices:
            conn.close()
            return

        configs = {row["device_id"]: dict(row) for row in cursor.execute("SELECT * FROM device_configurations").fetchall()}
        links = [dict(row) for row in cursor.execute("SELECT * FROM network_links").fetchall()]
        sys_settings = {row["key"]: row["value"] for row in cursor.execute("SELECT key, value FROM system_settings").fetchall()}
        auto_mode = sys_settings.get("auto_resolution_mode", "Approval Mode")

        now = datetime.datetime.now(datetime.timezone.utc).isoformat()

        for dev in devices:
            d_id = dev["id"]
            cfg = configs.get(d_id, {
                "latency_normal": 25.0,
                "latency_max": 80.0,
                "packet_loss_max": 2.5,
                "jitter_max": 15.0,
                "bandwidth_warning": 75.0,
                "bandwidth_critical": 90.0,
                "connection_loss_max_fails": 3,
                "dns_resolution_time_max": 100.0,
                "configured_capacity_mbps": 1000.0
            })

            # Check if this device has an active fault injection scenario
            fault = None
            with self.lock:
                fault = self.fault_injections.get(d_id)

            # Generate or probe metrics
            is_reachable = True
            lat = round(random.uniform(18.0, 32.0), 1)
            loss = 0.0
            jitter = round(random.uniform(1.5, 4.5), 1)
            bw = round(random.uniform(25.0, 48.0), 1)
            dns_val = round(random.uniform(18.0, 35.0), 1)
            http_val = round(random.uniform(40.0, 75.0), 1)
            fails = dev.get("consecutive_failures", 0)

            # Actual probe if not simulation or if requested
            if dev.get("is_simulation", 1) == 0:
                is_reachable, rtt, actual_loss = ping_host(dev["ip_address"])
                if is_reachable:
                    lat = round(rtt, 1)
                    loss = actual_loss
                else:
                    fails += 1
            else:
                # Simulation Mode: Apply Fault scenarios accurately if present
                if fault:
                    f_type = fault["type"]
                    if f_type == "high_latency":
                        lat = round(random.uniform(145.0, 260.0), 1)
                        jitter = round(random.uniform(25.0, 45.0), 1)
                    elif f_type == "connection_loss":
                        is_reachable = False
                        loss = 100.0
                        fails += 1
                        lat = 0.0
                    elif f_type == "packet_loss":
                        loss = round(random.uniform(18.0, 42.0), 1)
                        lat = round(random.uniform(60.0, 95.0), 1)
                    elif f_type == "bandwidth_congestion":
                        bw = round(random.uniform(92.0, 98.5), 1)
                        lat = round(random.uniform(70.0, 110.0), 1)
                    elif f_type == "dns_failure":
                        dns_val = round(random.uniform(350.0, 850.0), 1)
                    elif f_type == "router_failure":
                        is_reachable = False
                        loss = 100.0
                        fails += 1

            if is_reachable:
                fails = 0
                reach_status = "Reachable"
                dev_status = "Connected"
            else:
                reach_status = "Unreachable"
                dev_status = "Connection Failed" if fails >= cfg.get("connection_loss_max_fails", 3) else "Degraded"

            # Compute Availability
            avail = 0.0 if not is_reachable else (99.8 if fails == 0 else 85.0)

            # Insert Time-Series Metric Record
            cursor.execute('''
            INSERT INTO network_metrics
            (device_id, timestamp, latency_ms, packet_loss_pct, jitter_ms, upload_mbps, download_mbps,
             bandwidth_usage_pct, availability_pct, http_response_ms, dns_resolution_ms, throughput_mbps,
             connection_failure_rate, is_reachable, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (d_id, now, lat, loss, jitter, round(bw * 4.2, 1), round(bw * 8.5, 1),
                  bw, avail, http_val, dns_val, round(bw * 10.5, 1),
                  float(fails), 1 if is_reachable else 0, 'simulated' if dev.get('is_simulation', 1) else 'actual'))

            # Update Device Status in DB
            cursor.execute('''
            UPDATE devices SET status = ?, reachability_status = ?, consecutive_failures = ?, last_seen = ?
            WHERE id = ?
            ''', (dev_status, reach_status, fails, now, d_id))

            # Metric dict for engines
            metric_data = {
                "device_id": d_id,
                "latency_ms": lat,
                "packet_loss_pct": loss,
                "jitter_ms": jitter,
                "bandwidth_usage_pct": bw,
                "http_response_ms": http_val,
                "dns_resolution_ms": dns_val,
                "is_reachable": is_reachable,
                "availability_pct": avail
            }

            # 1. Anomaly Detection Engine
            anomalies = anomaly_detector.analyze_metric(dev, cfg, metric_data)
            for anom in anomalies:
                # Deduplicate recent active anomaly of same type
                existing = cursor.execute('''
                SELECT id FROM anomalies WHERE device_id = ? AND anomaly_type = ? AND status = 'Active'
                ''', (d_id, anom["anomaly_type"])).fetchone()
                
                if not existing:
                    cursor.execute('''
                    INSERT INTO anomalies (id, device_id, device_name, device_ip, anomaly_type, metric_name,
                                           current_value, expected_value, severity, detection_time, description,
                                           probable_cause, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')
                    ''', (anom["id"], anom["device_id"], anom["device_name"], anom["device_ip"], anom["anomaly_type"],
                          anom["metric_name"], anom["current_value"], anom["expected_value"], anom["severity"],
                          anom["detection_time"], anom["description"], anom["probable_cause"]))

                    # Generate Alert
                    alert_id = f"alt_{d_id}_{int(time.time())}_{random.randint(100, 999)}"
                    cursor.execute('''
                    INSERT INTO alerts (id, device_id, device_name, device_ip, problem, severity, current_metric,
                                        configured_threshold, probable_root_cause, recommended_fix, detected_time,
                                        resolution_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Unresolved')
                    ''', (alert_id, d_id, dev["name"], dev["ip_address"], anom["anomaly_type"], anom["severity"],
                          anom["current_value"], anom["expected_value"], anom["probable_cause"],
                          "Inspect and execute targeted automated recovery", now))

                    # 2. Run Root Cause Analysis
                    rca_res = rca_engine.diagnose(dev, metric_data, [anom], links)
                    rca_id = f"rca_{d_id}_{int(time.time())}"
                    cursor.execute('''
                    INSERT INTO root_cause_analyses (id, incident_id, device_id, problem_detected, probable_root_cause,
                                                    evidence, related_metrics, confidence_score, recommended_solution,
                                                    is_confirmed, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (rca_id, None, d_id, rca_res["problem"], rca_res["probable_root_cause"],
                          rca_res["evidence"], rca_res["related_metrics"], rca_res["confidence_score"],
                          rca_res["recommended_solution"], rca_res["is_confirmed"], now))

                    # 3. Outage Impact Prediction
                    impact_res = impact_engine.predict_impact(d_id)
                    impact_id = f"imp_{d_id}_{int(time.time())}"
                    cursor.execute('''
                    INSERT INTO impact_predictions (id, trigger_device_id, predicted_impact, affected_devices,
                                                    affected_services, impact_severity, confidence,
                                                    preventive_recommendation, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (impact_id, d_id, impact_res["predicted_impact"], impact_res["affected_devices"],
                          impact_res["affected_services"], impact_res["impact_severity"], impact_res["confidence"],
                          impact_res["preventive_recommendation"], now))

                    # 4. Incident Creation
                    inc_id = f"inc_{d_id}_{int(time.time())}"
                    cursor.execute('''
                    INSERT INTO incidents (id, device_id, device_name, problem, severity, root_cause,
                                          impact_prediction, resolution_action, status, detection_time,
                                          target_device_id, isolated_device_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?, ?)
                    ''', (inc_id, d_id, dev["name"], anom["anomaly_type"], anom["severity"],
                          rca_res["probable_root_cause"], impact_res["predicted_impact"],
                          rca_res["recommended_solution"], now, d_id, d_id))

                    # 5. Check Safe Auto-Resolution trigger
                    if auto_mode == "Safe Auto Mode":
                        from app.auto_resolution import auto_resolution_engine
                        # If action is safe low-risk, execute automatically
                        auto_resolution_engine.execute_resolution(inc_id, d_id, rca_res["recommended_solution"], mode="Safe Auto Mode")

        conn.commit()
        conn.close()

monitoring_engine = MonitoringEngine()
