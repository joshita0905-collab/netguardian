import subprocess
import socket
import time
import random
import datetime
from typing import Dict, Any, Tuple

def ping_host(host: str, count: int = 2, timeout_ms: int = 1000) -> Tuple[bool, float, float]:
    """
    Attempts actual ICMP ping on Windows or fallback socket probe.
    Returns (is_reachable, avg_rtt_ms, packet_loss_pct)
    """
    try:
        # Windows ping command: ping -n <count> -w <timeout_ms> <host>
        cmd = ["ping", "-n", str(count), "-w", str(timeout_ms), host]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=3)
        output = proc.stdout.lower()
        
        if "unreachable" in output or "timed out" in output or "could not find host" in output:
            return False, 0.0, 100.0
            
        # Parse latency
        # Windows ping outputs e.g. "Average = 24ms" or "round trip times in milli-seconds: Minimum = ... Average = 14ms"
        loss = 0.0
        if "loss" in output:
            import re
            m = re.search(r"\((\d+)%\s*loss\)", output)
            if m:
                loss = float(m.group(1))
                
        avg_rtt = 15.0
        if "average =" in output:
            import re
            m = re.search(r"average\s*=\s*(\d+)ms", output)
            if m:
                avg_rtt = float(m.group(1))
                return True, avg_rtt, loss
                
        return proc.returncode == 0, avg_rtt, loss
    except Exception:
        # Fallback to TCP probe on common ports
        try:
            start = time.time()
            s = socket.create_connection((host, 80), timeout=1.0)
            s.close()
            rtt = (time.time() - start) * 1000.0
            return True, rtt, 0.0
        except Exception:
            return False, 0.0, 100.0

def http_probe(host: str, port: int = 80) -> Tuple[bool, float]:
    """Measures actual HTTP connect response time"""
    start = time.time()
    try:
        s = socket.create_connection((host, port), timeout=1.5)
        s.close()
        rtt = (time.time() - start) * 1000.0
        return True, round(rtt, 2)
    except Exception:
        return False, 999.0

def dns_probe(domain: str = "google.com") -> Tuple[bool, float]:
    """Measures DNS lookup resolution time"""
    start = time.time()
    try:
        socket.gethostbyname(domain)
        rtt = (time.time() - start) * 1000.0
        return True, round(rtt, 2)
    except Exception:
        return False, 999.0
