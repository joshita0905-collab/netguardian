import os
import json
import datetime
from fastapi import FastAPI, Depends, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

from app.database import init_db, get_db
from app.auth import hash_password, verify_password, create_access_token, get_current_user
from app.monitor import monitoring_engine
from app.prober import ping_host, http_probe, dns_probe
from app.impact_engine import impact_engine
from app.rca_engine import rca_engine
from app.auto_resolution import auto_resolution_engine
from app.seed_data import seed_initial_topology

app = FastAPI(title="NetGuardian API", version="1.0.0")

# Enable CORS for local integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Database and Seed default network topology
init_db()
seed_initial_topology()
monitoring_engine.start()

# Frontend Static Files Mount
BASE_PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
FRONTEND_DIR = os.path.join(BASE_PROJECT_DIR, "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=os.path.join(FRONTEND_DIR, "static")), name="static")

@app.get("/")
def serve_index():
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "NetGuardian API is running. Frontend index.html not yet placed.", "path_checked": index_path}

# ================= AUTHENTICATION ROUTES =================

class LoginRequest(BaseModel):
    username: str
    password: str

class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str
    full_name: str
    role: Optional[str] = "network_admin"

@app.post("/api/auth/login")
def login(req: LoginRequest):
    conn = get_db()
    user = conn.cursor().execute("SELECT * FROM users WHERE username = ?", (req.username,)).fetchone()
    conn.close()
    if not user or not verify_password(req.password, user["password_hash"]):
        raise HTTPException(status_code=400, detail="Invalid username or password")
    
    token = create_access_token({"sub": user["username"], "role": user["role"], "id": user["id"]})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "full_name": user["full_name"],
            "role": user["role"]
        }
    }

@app.post("/api/auth/register")
def register(req: RegisterRequest):
    conn = get_db()
    cursor = conn.cursor()
    existing = cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?", (req.username, req.email)).fetchone()
    if existing:
        conn.close()
        raise HTTPException(status_code=400, detail="Username or email already registered")
    
    user_id = f"usr_{int(datetime.datetime.now().timestamp())}"
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cursor.execute('''
    INSERT INTO users (id, username, email, password_hash, full_name, role, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (user_id, req.username, req.email, hash_password(req.password), req.full_name, req.role, now))
    conn.commit()
    conn.close()
    return {"message": "User registered successfully"}

@app.get("/api/auth/me")
def get_me(user: dict = Depends(get_current_user)):
    return user

# ================= DASHBOARD & SUMMARY METRICS =================

@app.get("/api/dashboard/summary")
def get_dashboard_summary():
    conn = get_db()
    cursor = conn.cursor()

    devices = [dict(r) for r in cursor.execute("SELECT * FROM devices").fetchall()]
    total_devices = len(devices)
    active_devices = len([d for d in devices if d["status"] == "Connected" and d["reachability_status"] == "Reachable"])
    offline_devices = total_devices - active_devices

    active_anomalies = cursor.execute("SELECT COUNT(*) FROM anomalies WHERE status = 'Active'").fetchone()[0]
    critical_alerts = cursor.execute("SELECT COUNT(*) FROM alerts WHERE severity = 'Critical' AND resolution_status = 'Unresolved'").fetchone()[0]
    resolved_issues = cursor.execute("SELECT COUNT(*) FROM resolution_logs WHERE status = 'Resolved'").fetchone()[0]

    # Calculate overall network health score (%)
    health_score = 100.0
    if total_devices > 0:
        health_score -= (offline_devices / total_devices) * 40.0
        health_score -= min(30.0, active_anomalies * 5.0)
        health_score -= min(20.0, critical_alerts * 8.0)
    health_score = max(5.0, round(health_score, 1))

    conn.close()
    return {
        "health_score": health_score,
        "total_devices": total_devices,
        "active_devices": active_devices,
        "offline_devices": offline_devices,
        "active_anomalies": active_anomalies,
        "critical_alerts": critical_alerts,
        "resolved_issues": resolved_issues,
        "network_availability": 99.4 if offline_devices == 0 else round((active_devices / max(1, total_devices)) * 100, 1)
    }

# ================= DEVICE SELECTION & CONNECTION MODULE =================

class DeviceConnectRequest(BaseModel):
    name: str
    device_type: str
    ip_address: str
    hostname: Optional[str] = ""
    location: Optional[str] = "Main Office"
    protocol: Optional[str] = "ICMP Ping"
    credentials: Optional[str] = ""
    is_simulation: Optional[bool] = True

@app.get("/api/devices")
def list_devices():
    conn = get_db()
    devices = [dict(r) for r in conn.cursor().execute("SELECT * FROM devices ORDER BY name ASC").fetchall()]
    conn.close()
    return devices

@app.post("/api/devices/test-connection")
def test_device_connection(payload: Dict[str, Any] = Body(...)):
    ip = payload.get("ip_address", "127.0.0.1")
    is_sim = payload.get("is_simulation", True)
    
    if is_sim:
        return {
            "status": "Connected",
            "reachable": True,
            "latency_ms": 22.4,
            "packet_loss_pct": 0.0,
            "message": "Simulated device reached successfully via ICMP probe handshake."
        }
    
    # Real reachability probe
    is_reach, rtt, loss = ping_host(ip)
    return {
        "status": "Connected" if is_reach else "Connection Failed",
        "reachable": is_reach,
        "latency_ms": round(rtt, 1),
        "packet_loss_pct": loss,
        "message": f"Actual ICMP probe completed with {loss}% loss."
    }

@app.post("/api/devices/connect")
def connect_device(req: DeviceConnectRequest):
    conn = get_db()
    cursor = conn.cursor()
    dev_id = f"dev_{int(datetime.datetime.now().timestamp())}"
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    
    cursor.execute('''
    INSERT INTO devices (id, name, device_type, ip_address, hostname, location, protocol, credentials, is_simulation, status, reachability_status, consecutive_failures, last_seen, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Connected', 'Reachable', 0, ?, ?)
    ''', (dev_id, req.name, req.device_type, req.ip_address, req.hostname, req.location, req.protocol, req.credentials, 1 if req.is_simulation else 0, now, now))
    
    # Create default configuration
    cursor.execute('''
    INSERT INTO device_configurations (device_id, latency_normal, latency_max, packet_loss_max, jitter_max, bandwidth_warning, bandwidth_critical, connection_loss_max_fails, updated_at)
    VALUES (?, 25.0, 80.0, 2.5, 12.0, 75.0, 90.0, 3, ?)
    ''', (dev_id, now))

    # Connect to default distribution switch if exists
    sw = cursor.execute("SELECT id FROM devices WHERE device_type = 'Switch' LIMIT 1").fetchone()
    if sw and sw["id"] != dev_id:
        link_id = f"link_{int(datetime.datetime.now().timestamp())}"
        cursor.execute('''
        INSERT INTO network_links (id, source_device_id, target_device_id, link_type, status, bandwidth_capacity_mbps, latency_penalty_ms, packet_loss_penalty, created_at)
        VALUES (?, ?, ?, 'Ethernet 1Gbps', 'Up', 1000.0, 1.0, 0.0, ?)
        ''', (link_id, sw["id"], dev_id, now))

    conn.commit()
    conn.close()
    return {"message": f"Device {req.name} connected and enrolled into real-time monitoring.", "device_id": dev_id}

@app.post("/api/devices/{device_id}/disconnect")
def disconnect_device(device_id: str):
    conn = get_db()
    conn.cursor().execute("UPDATE devices SET status = 'Disconnected', reachability_status = 'Unreachable' WHERE id = ?", (device_id,))
    conn.commit()
    conn.close()
    return {"message": "Device disconnected from active monitoring."}

@app.post("/api/devices/{device_id}/reconnect")
def reconnect_device(device_id: str):
    conn = get_db()
    conn.cursor().execute("UPDATE devices SET status = 'Connected', reachability_status = 'Reachable', consecutive_failures = 0 WHERE id = ?", (device_id,))
    conn.commit()
    conn.close()
    return {"message": "Device reconnected successfully."}

@app.delete("/api/devices/{device_id}")
def delete_device(device_id: str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM devices WHERE id = ?", (device_id,))
    cursor.execute("DELETE FROM device_configurations WHERE device_id = ?", (device_id,))
    cursor.execute("DELETE FROM network_links WHERE source_device_id = ? OR target_device_id = ?", (device_id, device_id))
    cursor.execute("DELETE FROM network_metrics WHERE device_id = ?", (device_id,))
    cursor.execute("DELETE FROM anomalies WHERE device_id = ?", (device_id,))
    cursor.execute("DELETE FROM alerts WHERE device_id = ?", (device_id,))
    cursor.execute("DELETE FROM incidents WHERE device_id = ?", (device_id,))
    conn.commit()
    conn.close()
    return {"message": "Device and associated telemetry removed."}

# ================= DEVICE CONFIGURATIONS & THRESHOLDS =================

@app.get("/api/devices/{device_id}/config")
def get_device_config(device_id: str):
    conn = get_db()
    cfg = conn.cursor().execute("SELECT * FROM device_configurations WHERE device_id = ?", (device_id,)).fetchone()
    conn.close()
    if not cfg:
        return {
            "device_id": device_id,
            "latency_normal": 25.0,
            "latency_max": 80.0,
            "packet_loss_max": 2.5,
            "jitter_max": 12.0,
            "bandwidth_warning": 75.0,
            "bandwidth_critical": 90.0,
            "connection_loss_max_fails": 3,
            "dns_resolution_time_max": 120.0,
            "monitoring_interval_sec": 4
        }
    return dict(cfg)

@app.post("/api/devices/{device_id}/config")
def update_device_config(device_id: str, payload: Dict[str, Any] = Body(...)):
    conn = get_db()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT OR REPLACE INTO device_configurations
    (device_id, latency_normal, latency_max, packet_loss_max, jitter_max, bandwidth_warning, bandwidth_critical, connection_loss_max_fails, dns_resolution_time_max, monitoring_interval_sec, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (device_id, payload.get("latency_normal", 25.0), payload.get("latency_max", 80.0),
          payload.get("packet_loss_max", 2.5), payload.get("jitter_max", 12.0),
          payload.get("bandwidth_warning", 75.0), payload.get("bandwidth_critical", 90.0),
          payload.get("connection_loss_max_fails", 3), payload.get("dns_resolution_time_max", 120.0),
          payload.get("monitoring_interval_sec", 4), now))
    conn.commit()
    conn.close()
    return {"message": "Default network configuration and thresholds updated."}

# ================= TIME-SERIES METRICS & CHARTS =================

@app.get("/api/metrics/recent")
def get_recent_metrics(device_id: Optional[str] = None, limit: int = 30):
    conn = get_db()
    cursor = conn.cursor()
    if device_id:
        rows = cursor.execute('''
        SELECT * FROM network_metrics WHERE device_id = ? ORDER BY id DESC LIMIT ?
        ''', (device_id, limit)).fetchall()
    else:
        rows = cursor.execute('''
        SELECT * FROM network_metrics ORDER BY id DESC LIMIT ?
        ''', (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in reversed(rows)]

# ================= ANOMALIES & ALERTS =================

@app.get("/api/anomalies")
def list_anomalies(status: Optional[str] = None):
    conn = get_db()
    cursor = conn.cursor()
    if status:
        rows = cursor.execute("SELECT * FROM anomalies WHERE status = ? ORDER BY detection_time DESC LIMIT 50", (status,)).fetchall()
    else:
        rows = cursor.execute("SELECT * FROM anomalies ORDER BY detection_time DESC LIMIT 50").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/api/alerts")
def list_alerts(severity: Optional[str] = None):
    conn = get_db()
    cursor = conn.cursor()
    if severity:
        rows = cursor.execute("SELECT * FROM alerts WHERE severity = ? ORDER BY detected_time DESC LIMIT 50", (severity,)).fetchall()
    else:
        rows = cursor.execute("SELECT * FROM alerts ORDER BY detected_time DESC LIMIT 50").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/api/alerts/{alert_id}/acknowledge")
def acknowledge_alert(alert_id: str, user: dict = Depends(get_current_user)):
    conn = get_db()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn.cursor().execute('''
    UPDATE alerts SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = ? WHERE id = ?
    ''', (user.get("username", "admin"), now, alert_id))
    conn.commit()
    conn.close()
    return {"message": "Alert acknowledged."}

@app.post("/api/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: str):
    conn = get_db()
    conn.cursor().execute("UPDATE alerts SET resolution_status = 'Resolved' WHERE id = ?", (alert_id,))
    conn.commit()
    conn.close()
    return {"message": "Alert marked as resolved."}

# ================= ROOT CAUSE ANALYSIS & INCIDENTS =================

@app.get("/api/rca")
def list_rca():
    conn = get_db()
    rows = conn.cursor().execute('''
    SELECT r.*, d.name as device_name, d.ip_address as device_ip 
    FROM root_cause_analyses r
    JOIN devices d ON r.device_id = d.id
    ORDER BY r.created_at DESC LIMIT 30
    ''').fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/api/incidents")
def list_incidents():
    conn = get_db()
    rows = conn.cursor().execute("SELECT * FROM incidents ORDER BY detection_time DESC LIMIT 40").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/api/incidents/{incident_id}/status")
def update_incident_status(incident_id: str, payload: Dict[str, str] = Body(...)):
    new_status = payload.get("status", "Resolved")
    conn = get_db()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn.cursor().execute('''
    UPDATE incidents SET status = ?, resolution_time = ? WHERE id = ?
    ''', (new_status, now if new_status == "Resolved" else None, incident_id))
    conn.commit()
    conn.close()
    return {"message": f"Incident updated to {new_status}"}

# ================= OUTAGE IMPACT PREDICTION =================

@app.get("/api/predictions")
def list_predictions():
    conn = get_db()
    rows = conn.cursor().execute('''
    SELECT p.*, d.name as trigger_device_name, d.device_type, d.ip_address
    FROM impact_predictions p
    JOIN devices d ON p.trigger_device_id = d.id
    ORDER BY p.created_at DESC LIMIT 30
    ''').fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/api/predictions/simulate")
def simulate_what_if(payload: Dict[str, str] = Body(...)):
    device_id = payload.get("device_id")
    if not device_id:
        raise HTTPException(status_code=400, detail="device_id required")
    res = impact_engine.predict_impact(device_id)
    return res

# ================= AUTO RESOLUTION & DEVICE PROTECTION =================

@app.get("/api/resolution/logs")
def get_resolution_logs():
    conn = get_db()
    rows = conn.cursor().execute('''
    SELECT l.*, d.name as device_name, d.ip_address as device_ip
    FROM resolution_logs l
    JOIN devices d ON l.device_id = d.id
    ORDER BY l.started_at DESC LIMIT 40
    ''').fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/api/resolution/execute")
def execute_auto_resolution(payload: Dict[str, Any] = Body(...)):
    incident_id = payload.get("incident_id")
    device_id = payload.get("device_id")
    action_name = payload.get("action_name", "Clear Interface Buffer & Traffic Shaping QoS")
    mode = payload.get("mode", "Approval Mode")

    if not device_id:
        raise HTTPException(status_code=400, detail="device_id required")

    result = auto_resolution_engine.execute_resolution(incident_id, device_id, action_name, mode)
    return result

@app.post("/api/resolution/{log_id}/rollback")
def rollback_action(log_id: str):
    res = auto_resolution_engine.rollback_resolution(log_id)
    return res

@app.get("/api/resolution/protection-status")
def get_protection_status():
    conn = get_db()
    cursor = conn.cursor()
    devices = [dict(r) for r in cursor.execute("SELECT id, name, device_type, ip_address, status, reachability_status FROM devices").fetchall()]
    recent_logs = [dict(r) for r in cursor.execute("SELECT * FROM resolution_logs ORDER BY started_at DESC LIMIT 5").fetchall()]
    conn.close()

    return {
        "protection_active": True,
        "isolation_protocol": "Hardware & Port-scoped Remediation Guard",
        "peer_devices_monitored": len(devices),
        "zero_side_effect_guarantee": "Strict Topology Isolation Check",
        "devices": devices,
        "recent_protection_events": recent_logs
    }

# ================= NETWORK TOPOLOGY & LINK CONNECTIONS =================

class CreateLinkRequest(BaseModel):
    source_device_id: str
    target_device_id: str
    link_type: Optional[str] = "Ethernet 1Gbps"

@app.get("/api/topology")
def get_topology():
    conn = get_db()
    cursor = conn.cursor()
    devices = [dict(r) for r in cursor.execute("SELECT id, name, device_type, ip_address, location, status, reachability_status FROM devices").fetchall()]
    links = [dict(r) for r in cursor.execute("SELECT * FROM network_links").fetchall()]
    conn.close()
    return {"nodes": devices, "edges": links}

@app.post("/api/topology/connect")
def create_topology_link(req: CreateLinkRequest):
    if req.source_device_id == req.target_device_id:
        raise HTTPException(status_code=400, detail="Cannot link device to itself")
    
    conn = get_db()
    cursor = conn.cursor()

    # Check if link exists
    exists = cursor.execute('''
    SELECT id FROM network_links 
    WHERE (source_device_id = ? AND target_device_id = ?) 
       OR (source_device_id = ? AND target_device_id = ?)
    ''', (req.source_device_id, req.target_device_id, req.target_device_id, req.source_device_id)).fetchone()

    if exists:
        conn.close()
        return {"message": "Link already exists between these devices", "link_id": exists["id"]}

    link_id = f"link_{int(datetime.datetime.now().timestamp())}"
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cursor.execute('''
    INSERT INTO network_links (id, source_device_id, target_device_id, link_type, status, bandwidth_capacity_mbps, latency_penalty_ms, packet_loss_penalty, created_at)
    VALUES (?, ?, ?, ?, 'Up', 1000.0, 1.0, 0.0, ?)
    ''', (link_id, req.source_device_id, req.target_device_id, req.link_type, now))
    conn.commit()
    conn.close()
    return {"message": "3D network link created successfully", "link_id": link_id}

@app.delete("/api/topology/disconnect")
def delete_topology_link(source_id: str, target_id: str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
    DELETE FROM network_links 
    WHERE (source_device_id = ? AND target_device_id = ?) 
       OR (source_device_id = ? AND target_device_id = ?)
    ''', (source_id, target_id, target_id, source_id))
    conn.commit()
    conn.close()
    return {"message": "Link disconnected"}

# ================= SIMULATION SCENARIO INJECTOR =================

@app.post("/api/simulation/inject")
def inject_simulation_scenario(payload: Dict[str, Any] = Body(...)):
    scenario = payload.get("scenario") # normal, high_latency, connection_loss, packet_loss, router_failure, dns_failure
    device_id = payload.get("device_id")

    conn = get_db()
    cursor = conn.cursor()

    if scenario == "normal":
        monitoring_engine.clear_all_faults()
        cursor.execute("UPDATE devices SET status = 'Connected', reachability_status = 'Reachable', consecutive_failures = 0")
        conn.commit()
        conn.close()
        return {"message": "All simulation faults cleared. Network operating under healthy baseline conditions."}

    # If no specific device specified, pick first endpoint or router appropriately
    if not device_id:
        if scenario == "router_failure":
            row = cursor.execute("SELECT id FROM devices WHERE device_type = 'Router' LIMIT 1").fetchone()
            device_id = row["id"] if row else None
        else:
            row = cursor.execute("SELECT id FROM devices WHERE device_type NOT IN ('Router', 'Switch') LIMIT 1").fetchone()
            device_id = row["id"] if row else None

    if not device_id:
        conn.close()
        raise HTTPException(status_code=400, detail="No suitable device found for simulation")

    monitoring_engine.set_device_fault(device_id, scenario)
    dev_name = cursor.execute("SELECT name FROM devices WHERE id = ?", (device_id,)).fetchone()["name"]
    conn.close()

    return {
        "message": f"Scenario '{scenario}' actively injected on device {dev_name}.",
        "target_device_id": device_id,
        "scenario": scenario
    }

# ================= ADMIN SETTINGS & EXPORTS =================

@app.get("/api/admin/settings")
def get_admin_settings():
    conn = get_db()
    rows = conn.cursor().execute("SELECT key, value FROM system_settings").fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}

@app.post("/api/admin/settings")
def update_admin_settings(payload: Dict[str, str] = Body(...)):
    conn = get_db()
    cursor = conn.cursor()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for k, v in payload.items():
        cursor.execute("INSERT OR REPLACE INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)", (k, v, now))
    conn.commit()
    conn.close()
    return {"message": "System administration settings updated successfully."}

@app.get("/api/reports/export")
def export_reports(format: str = "json"):
    conn = get_db()
    cursor = conn.cursor()
    devices = [dict(r) for r in cursor.execute("SELECT * FROM devices").fetchall()]
    metrics = [dict(r) for r in cursor.execute("SELECT * FROM network_metrics ORDER BY id DESC LIMIT 50").fetchall()]
    anomalies = [dict(r) for r in cursor.execute("SELECT * FROM anomalies ORDER BY detection_time DESC LIMIT 50").fetchall()]
    incidents = [dict(r) for r in cursor.execute("SELECT * FROM incidents ORDER BY detection_time DESC LIMIT 50").fetchall()]
    resolutions = [dict(r) for r in cursor.execute("SELECT * FROM resolution_logs ORDER BY started_at DESC LIMIT 50").fetchall()]
    conn.close()

    report_payload = {
        "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "total_devices": len(devices),
        "devices": devices,
        "metrics_summary": metrics,
        "anomalies": anomalies,
        "incidents": incidents,
        "resolutions": resolutions
    }

    if format == "csv":
        import io
        import csv
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Timestamp", "Device Name", "Problem", "Severity", "Root Cause", "Status"])
        for inc in incidents:
            writer.writerow([inc.get("detection_time"), inc.get("device_name"), inc.get("problem"), inc.get("severity"), inc.get("root_cause"), inc.get("status")])
        output.seek(0)
        from fastapi.responses import Response
        return Response(content=output.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=netguardian_report.csv"})

    return report_payload
