import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
import random
import datetime
from typing import Dict, Any, List, Optional
from app.database import get_db

class AnomalyDetector:
    def __init__(self):
        # Isolation Forest baseline model
        self.model = IsolationForest(contamination=0.08, random_state=42)
        self.fitted = False
        self._init_baseline()

    def _init_baseline(self):
        """Train baseline model with typical healthy network patterns"""
        # Features: [latency_ms, packet_loss_pct, jitter_ms, bandwidth_usage_pct, http_response_ms, dns_resolution_ms]
        np.random.seed(42)
        n_samples = 400
        normal_latency = np.random.normal(loc=22.0, scale=6.0, size=n_samples).clip(5, 75)
        normal_loss = np.random.exponential(scale=0.3, size=n_samples).clip(0, 2.0)
        normal_jitter = np.random.normal(loc=3.5, scale=1.2, size=n_samples).clip(0.5, 12)
        normal_bw = np.random.normal(loc=35.0, scale=12.0, size=n_samples).clip(5, 70)
        normal_http = np.random.normal(loc=65.0, scale=15.0, size=n_samples).clip(20, 180)
        normal_dns = np.random.normal(loc=25.0, scale=7.0, size=n_samples).clip(5, 60)

        X = np.column_stack([normal_latency, normal_loss, normal_jitter, normal_bw, normal_http, normal_dns])
        self.model.fit(X)
        self.fitted = True

    def analyze_metric(self, device: dict, config: dict, metric: dict) -> List[dict]:
        """
        Combines Isolation Forest Machine Learning + Configurable Statistical Thresholds
        to catch:
        1. Latency spikes
        2. Packet loss
        3. Abnormal Jitter
        4. Bandwidth Congestion
        5. Connection Loss / Offline
        6. DNS Resolution Spikes
        7. HTTP Response Degradation
        """
        anomalies = []
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        
        # 1. Physical / Connectivity Check
        if not metric.get("is_reachable", True):
            anomalies.append({
                "id": f"anom_{metric['device_id']}_{int(datetime.datetime.now().timestamp())}_offline",
                "device_id": device["id"],
                "device_name": device["name"],
                "device_ip": device["ip_address"],
                "anomaly_type": "Connection Loss",
                "metric_name": "Device Reachability",
                "current_value": 0.0,
                "expected_value": 1.0,
                "severity": "Critical",
                "detection_time": now,
                "description": f"Device {device['name']} ({device['ip_address']}) is completely unreachable. 0% availability.",
                "probable_cause": "Network Link Failure / Hardware Power Loss / Severe IP Conflict"
            })
            return anomalies

        # 2. Threshold Detection against user-configured default thresholds
        lat = metric.get("latency_ms", 0.0)
        lat_max = config.get("latency_max", 100.0)
        lat_norm = config.get("latency_normal", 35.0)
        if lat > lat_max:
            severity = "Critical" if lat > lat_max * 1.5 else "High"
            anomalies.append({
                "id": f"anom_{device['id']}_{int(datetime.datetime.now().timestamp())}_lat",
                "device_id": device["id"],
                "device_name": device["name"],
                "device_ip": device["ip_address"],
                "anomaly_type": "Sudden Latency Increase",
                "metric_name": "Latency (RTT)",
                "current_value": round(lat, 2),
                "expected_value": round(lat_norm, 2),
                "severity": severity,
                "detection_time": now,
                "description": f"Round-trip latency ({lat:.1f}ms) exceeded threshold limit ({lat_max:.1f}ms).",
                "probable_cause": "Interface Buffer Queue Overflow / Upstream Route Congestion"
            })

        loss = metric.get("packet_loss_pct", 0.0)
        loss_max = config.get("packet_loss_max", 2.5)
        if loss > loss_max:
            severity = "Critical" if loss > 15.0 else "High" if loss > 5.0 else "Medium"
            anomalies.append({
                "id": f"anom_{device['id']}_{int(datetime.datetime.now().timestamp())}_loss",
                "device_id": device["id"],
                "device_name": device["name"],
                "device_ip": device["ip_address"],
                "anomaly_type": "High Packet Loss",
                "metric_name": "Packet Loss",
                "current_value": round(loss, 2),
                "expected_value": 0.0,
                "severity": severity,
                "detection_time": now,
                "description": f"Packet loss rate reached {loss:.1f}%, exceeding acceptable ceiling {loss_max}%.",
                "probable_cause": "Faulty Physical Cable / Duplex Mismatch / Switch Port Overload"
            })

        bw = metric.get("bandwidth_usage_pct", 0.0)
        bw_crit = config.get("bandwidth_critical", 90.0)
        bw_warn = config.get("bandwidth_warning", 75.0)
        if bw > bw_warn:
            severity = "Critical" if bw >= bw_crit else "High"
            anomalies.append({
                "id": f"anom_{device['id']}_{int(datetime.datetime.now().timestamp())}_bw",
                "device_id": device["id"],
                "device_name": device["name"],
                "device_ip": device["ip_address"],
                "anomaly_type": "Bandwidth Congestion",
                "metric_name": "Bandwidth Utilization",
                "current_value": round(bw, 1),
                "expected_value": round(bw_warn, 1),
                "severity": severity,
                "detection_time": now,
                "description": f"Bandwidth utilization at {bw:.1f}% is saturating the configured pipe capacity.",
                "probable_cause": "Unthrottled Broadcast Storm / Bulk Data Transfer / Rogue Process"
            })

        dns_val = metric.get("dns_resolution_ms", 0.0)
        dns_max = config.get("dns_resolution_time_max", 120.0)
        if dns_val > dns_max:
            severity = "Critical" if dns_val > 400 else "Medium"
            anomalies.append({
                "id": f"anom_{device['id']}_{int(datetime.datetime.now().timestamp())}_dns",
                "device_id": device["id"],
                "device_name": device["name"],
                "device_ip": device["ip_address"],
                "anomaly_type": "DNS Resolution Failure/Delay",
                "metric_name": "DNS Resolution Time",
                "current_value": round(dns_val, 1),
                "expected_value": 25.0,
                "severity": severity,
                "detection_time": now,
                "description": f"DNS query lookup delayed to {dns_val:.1f}ms (threshold: {dns_max}ms).",
                "probable_cause": "Primary DNS Server Unresponsive / Corrupted Local Resolver Cache"
            })

        # 3. Isolation Forest ML Multivariable Anomaly Detection
        if self.fitted:
            features = np.array([[
                metric.get("latency_ms", 20.0),
                metric.get("packet_loss_pct", 0.0),
                metric.get("jitter_ms", 3.0),
                metric.get("bandwidth_usage_pct", 30.0),
                metric.get("http_response_ms", 50.0),
                metric.get("dns_resolution_ms", 25.0)
            ]])
            score = self.model.decision_function(features)[0]
            is_outlier = self.model.predict(features)[0] == -1
            
            if is_outlier and len(anomalies) == 0:
                # Multivariate subtle degradation not caught by simple single-threshold
                anomalies.append({
                    "id": f"anom_{device['id']}_{int(datetime.datetime.now().timestamp())}_iforest",
                    "device_id": device["id"],
                    "device_name": device["name"],
                    "device_ip": device["ip_address"],
                    "anomaly_type": "Multivariate Behavioral Deviation (Isolation Forest)",
                    "metric_name": "ML Composite Score",
                    "current_value": round(float(score), 3),
                    "expected_value": 0.15,
                    "severity": "Medium",
                    "detection_time": now,
                    "description": f"Isolation Forest detected abnormal multi-metric divergence (score: {score:.3f}).",
                    "probable_cause": "Subtle TCP Window Degradation / Jitter Variance / Intermittent micro-bursts"
                })

        return anomalies

anomaly_detector = AnomalyDetector()
