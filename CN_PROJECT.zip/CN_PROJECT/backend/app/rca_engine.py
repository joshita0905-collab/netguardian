import datetime
import json
from typing import Dict, Any, List, Optional
from app.database import get_db

class RootCauseEngine:
    """
    Evaluates metric cross-correlations, historical failure trends,
    and network topology edge states to distinguish confirmed root causes
    from transient anomalies.
    """
    def diagnose(self, device: dict, metric: dict, recent_anomalies: List[dict], topology_links: List[dict]) -> dict:
        problem = "Unknown Performance Degradation"
        probable_cause = "Transient Network Fluctuations"
        evidence_list = []
        related_metrics = {}
        confidence = 0.65
        solution = "Inspect device physical health and trace route hops."
        is_confirmed = False

        is_reachable = metric.get("is_reachable", True)
        lat = metric.get("latency_ms", 20.0)
        loss = metric.get("packet_loss_pct", 0.0)
        jitter = metric.get("jitter_ms", 3.0)
        bw = metric.get("bandwidth_usage_pct", 30.0)
        dns_val = metric.get("dns_resolution_ms", 25.0)

        # 1. Complete Connection Loss / Offline
        if not is_reachable or loss >= 95.0:
            problem = "Complete Connection Loss & Host Unreachable"
            # Check upstream links
            has_dead_link = any(link["status"] != "Up" for link in topology_links if link["target_device_id"] == device["id"] or link["source_device_id"] == device["id"])
            if has_dead_link:
                probable_cause = "Physical Link Failure / Port Link Down"
                evidence_list.append("Connected physical uplink status changed to Down.")
                evidence_list.append("100% ICMP and TCP probe loss.")
                confidence = 0.95
                solution = "Re-route traffic via redundant switch port link or restart interface."
                is_confirmed = True
            else:
                probable_cause = "Device Hardware Power Failure or Local Network Interface Crash"
                evidence_list.append("Probing subsystem received 0 responses across 5 consecutive checks.")
                evidence_list.append("Upstream switch port remains active but device does not respond to ARP/ICMP.")
                confidence = 0.88
                solution = "Perform safe device interface soft-reset or check physical power cord."

        # 2. DNS Failure
        elif dns_val > 150.0:
            problem = "DNS Lookup Timeout and Resolution Failure"
            probable_cause = "Corrupted Local Resolver Cache or Unresponsive Primary Nameserver"
            evidence_list.append(f"DNS query latency spiked to {dns_val:.1f}ms (normal baseline: <30ms).")
            evidence_list.append(f"Direct IP latency is normal ({lat:.1f}ms), proving IP routing is intact.")
            confidence = 0.92
            solution = "Flush Local DNS Cache & Switch Failover Resolver (1.1.1.1 / 8.8.8.8)."
            is_confirmed = True

        # 3. High Bandwidth Overload & Buffer Congestion
        elif bw >= 85.0:
            problem = "Severe Bandwidth Saturation and Bufferbloat"
            probable_cause = "Uncontrolled Bulk Transfer or Rogue Process Saturating Link"
            evidence_list.append(f"Bandwidth utilization reached {bw:.1f}% of port capacity.")
            if lat > 60.0:
                evidence_list.append(f"Simultaneous queue-induced latency increase ({lat:.1f}ms).")
            confidence = 0.89
            solution = "Apply device-specific QoS traffic shaping and clear interface output queue."

        # 4. High Packet Loss & Link Integrity
        elif loss > 10.0:
            problem = "Excessive Packet Drop and Transmission Retries"
            probable_cause = "Physical Ethernet Link Duplex Mismatch or Switch Port Degradation"
            evidence_list.append(f"Measured packet drop rate: {loss:.1f}%.")
            evidence_list.append(f"Jitter variance elevated to {jitter:.1f}ms.")
            confidence = 0.85
            solution = "Clear Interface Buffer & Traffic Shaping QoS on affected interface."

        # 5. High Latency Alone
        elif lat > 80.0:
            problem = "High Round-Trip Latency and Queue Stalling"
            probable_cause = "Interface Buffer Queue Overflow & TCP Window Shrinking"
            evidence_list.append(f"Average RTT is {lat:.1f}ms (threshold exceeded).")
            evidence_list.append("No corresponding loss, pointing to buffering rather than physical link break.")
            confidence = 0.82
            solution = "Clear Interface Buffer & Traffic Shaping QoS."

        related_metrics = {
            "latency_ms": round(lat, 1),
            "packet_loss_pct": round(loss, 1),
            "jitter_ms": round(jitter, 1),
            "bandwidth_usage_pct": round(bw, 1),
            "dns_resolution_ms": round(dns_val, 1)
        }

        return {
            "problem": problem,
            "probable_root_cause": probable_cause,
            "evidence": "; ".join(evidence_list) if evidence_list else "Performance variance across multiple probe rounds.",
            "related_metrics": json.dumps(related_metrics),
            "confidence_score": round(confidence, 2),
            "recommended_solution": solution,
            "is_confirmed": 1 if is_confirmed else 0
        }

rca_engine = RootCauseEngine()
